# Sz plus (Android)

Same app as the iOS version: clients enter **server URL, username and password** (Xtream Codes API) and get Live TV, Movies and Series.

## Features
- **Intro animation** when the app opens (light ring, logo spin-in).
- **Home tab:** auto-scrolling hero carousel of movies with a Play button, your favorite channels, new movies and new series rows.
- **Player gestures:** double-tap left/right to skip 10 seconds, swipe up/down on the left side for brightness and on the right side for volume.
- Sz plus lime (#82e705) on near-black, glowing animated login, glass tab bar with a sliding lens, springy press effects, zoom/fade transitions.
- Fast: lists are saved on the phone and open instantly, then refresh in the background. Pull down to refresh. Posters are cached and shrunk by Coil.
- Live channels start quickly (small buffers), try HLS first and then .ts.
- TV guide in the player (now / next with a progress bar) for live channels.
- Arabic and English with right-to-left layout. Language switch in Account.
- Account page: status, expiry, connections, Data saver (caps video bitrate).
- Favorites for live channels.

## Get the APK (no Android Studio needed)
1. Create a new private GitHub repo and upload **everything in this folder** (keep `.github` and `app/szplus.jks`).
2. Open **Actions > Build APK > Run workflow** (it also runs on every commit).
3. After about 5 to 10 minutes, download the **SzPlus-apk** artifact. It contains `SzPlus.apk`.
4. Send the APK to clients. On their phone they allow "Install unknown apps" once.

The APK is already signed with `app/szplus.jks`, so future updates install over the old version. **Keep that file safe and never change it.**

## Brand it
| What | Where |
|---|---|
| Colors | `app/src/main/java/com/szplus/player/ui/Theme.kt` |
| Name and Arabic text | `app/src/main/res/values/strings.xml`, `values-ar/strings.xml` |
| In-app logo | `app/src/main/res/drawable-nodpi/logo.png` |
| Launcher icon | `mipmap-*/ic_launcher.png` and `drawable-nodpi/ic_launcher_foreground.png` |
| Package name | `app/build.gradle.kts` (`applicationId`) |

If a build fails, open the failed step and look for lines starting with `e:` (Kotlin errors) or `error:`.
