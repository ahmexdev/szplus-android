package com.szplus.player.ui

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import com.szplus.player.AppViewModel
import com.szplus.player.R
import com.szplus.player.data.Movie
import com.szplus.player.data.PlayItem
import kotlinx.coroutines.delay
import kotlin.math.absoluteValue

@Composable
fun HomeScreen(vm: AppViewModel) {
    val api = vm.api ?: return
    val movies = vm.movies ?: return
    val series = vm.series ?: return
    val live = vm.live ?: return
    LaunchedEffect(movies, series, live) {
        movies.load(); series.load(); live.load()
    }

    val hero = remember(movies.items) {
        movies.items.filter { !it.icon.isNullOrBlank() }.takeLast(30).shuffled().take(6)
    }
    val newMovies = remember(movies.items) {
        movies.items.filter { !it.icon.isNullOrBlank() }.takeLast(24).reversed()
    }
    val newSeries = remember(series.items) {
        series.items.filter { !it.cover.isNullOrBlank() }.takeLast(24).reversed()
    }
    val myChannels = remember(live.items, vm.favorites) {
        live.items.filter { it.id in vm.favorites }.take(24)
    }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Row(
            Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Image(painterResource(R.drawable.logo), null, Modifier.size(38.dp))
            Spacer(Modifier.width(10.dp))
            Text(
                t(R.string.brand_name), fontSize = 26.sp, fontWeight = FontWeight.ExtraBold,
                style = androidx.compose.ui.text.TextStyle(brush = Brand.Gradient),
            )
        }

        if (hero.isNotEmpty()) {
            HeroPager(hero) { m ->
                vm.playing = PlayItem(m.id.toString(), m.name, listOf(api.movieUrl(m)))
            }
        } else {
            Box(
                Modifier.padding(horizontal = 28.dp).fillMaxWidth().height(440.dp)
                    .clip(RoundedCornerShape(30.dp)).shimmer()
            )
        }

        if (myChannels.isNotEmpty()) {
            SectionTitle(t(R.string.home_my_channels))
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(myChannels) { s ->
                    Column(
                        Modifier.width(84.dp).pressable(0.93f) {
                            vm.playing = PlayItem(s.id.toString(), s.name, api.liveUrls(s), epgStreamId = s.id)
                        },
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        PosterImage(
                            s.icon,
                            Modifier.size(84.dp).softCard(22.dp).padding(10.dp),
                            ContentScale.Fit,
                        )
                        Text(s.name, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = Color.White.copy(0.8f), modifier = Modifier.padding(top = 5.dp))
                    }
                }
            }
        }

        if (newMovies.isNotEmpty()) {
            SectionTitle(t(R.string.home_new_movies))
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(newMovies) { m ->
                    Box(Modifier.width(120.dp)) {
                        PosterCard(m.name, m.icon) {
                            vm.playing = PlayItem(m.id.toString(), m.name, listOf(api.movieUrl(m)))
                        }
                    }
                }
            }
        }

        if (newSeries.isNotEmpty()) {
            SectionTitle(t(R.string.home_new_series))
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(newSeries) { s ->
                    Box(Modifier.width(120.dp)) {
                        PosterCard(s.name, s.cover) { vm.pendingSeries = s }
                    }
                }
            }
        }

        Spacer(Modifier.height(120.dp))
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, Modifier.padding(horizontal = 20.dp), fontSize = 19.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun HeroPager(items: List<Movie>, onPlay: (Movie) -> Unit) {
    val state = rememberPagerState(pageCount = { items.size })
    LaunchedEffect(items) {
        while (true) {
            delay(5_000)
            state.animateScrollToPage((state.currentPage + 1) % items.size)
        }
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        HorizontalPager(
            state = state,
            contentPadding = PaddingValues(horizontal = 28.dp),
            pageSpacing = 12.dp,
            modifier = Modifier.fillMaxWidth().height(440.dp),
        ) { page ->
            val m = items[page]
            val offset = ((state.currentPage - page) + state.currentPageOffsetFraction).absoluteValue
            val k = 1f - offset.coerceIn(0f, 1f)
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val s = lerp(0.88f, 1f, k)
                        scaleX = s
                        scaleY = s
                        alpha = lerp(0.45f, 1f, k)
                    }
                    .clip(RoundedCornerShape(30.dp))
                    .border(0.8.dp, Color.White.copy(0.18f), RoundedCornerShape(30.dp))
            ) {
                PosterImage(m.icon, Modifier.fillMaxSize())
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(
                            0.45f to Color.Transparent,
                            1f to Color.Black.copy(0.9f),
                        )
                    )
                )
                Column(
                    Modifier.align(Alignment.BottomStart).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(m.name, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2,
                        overflow = TextOverflow.Ellipsis, color = Color.White)
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(50))
                            .background(Brand.Gradient)
                            .pressable(0.94f) { onPlay(m) }
                            .padding(start = 14.dp, end = 22.dp, top = 10.dp, bottom = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Rounded.PlayArrow, null, tint = Brand.OnAccent)
                        Spacer(Modifier.width(6.dp))
                        Text(t(R.string.play), color = Brand.OnAccent, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            repeat(items.size) { i ->
                val w by animateDpAsState(if (state.currentPage == i) 22.dp else 7.dp, label = "dot")
                Box(
                    Modifier.width(w).height(7.dp).clip(CircleShape)
                        .background(if (state.currentPage == i) Brand.Accent else Color.White.copy(0.3f))
                )
            }
        }
    }
}
