package com.szplus.player.data

data class Credentials(val server: String, val username: String, val password: String)

data class Category(val id: String, val name: String)

data class LiveStream(val id: Int, val name: String, val icon: String?, val categoryId: String?)

data class Movie(val id: Int, val name: String, val icon: String?, val categoryId: String?, val ext: String)

data class Series(val id: Int, val name: String, val cover: String?, val categoryId: String?, val plot: String?)

data class Episode(val id: String, val title: String, val number: Int, val ext: String)

data class SeriesInfo(val plot: String?, val seasons: Map<String, List<Episode>>)

data class EpgEntry(val title: String, val start: Long, val end: Long)

data class AccountInfo(
    val status: String,
    val expiresAt: Long?,
    val maxConnections: String?,
    val activeConnections: String?,
)

/** What the player needs. [urls] are tried in order if one fails. */
data class PlayItem(
    val id: String,
    val title: String,
    val urls: List<String>,
    val epgStreamId: Int? = null,
)
