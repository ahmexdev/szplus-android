package com.szplus.player.ui

import android.app.Activity
import android.content.Context
import android.media.AudioManager
import android.view.WindowManager
import android.content.pm.ActivityInfo
import android.view.View
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.szplus.player.R
import com.szplus.player.data.EpgEntry
import com.szplus.player.data.PlayItem
import com.szplus.player.data.XtreamApi
import kotlinx.coroutines.delay

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    item: PlayItem,
    api: XtreamApi?,
    dataSaver: Boolean,
    activity: Activity?,
    onClose: () -> Unit,
) {
    val context = LocalContext.current
    var failed by remember { mutableStateOf(false) }
    var overlay by remember { mutableStateOf(true) }
    var showEpg by remember { mutableStateOf(false) }
    var epg by remember { mutableStateOf<List<EpgEntry>>(emptyList()) }
    val urlIndex = remember { intArrayOf(0) }
    var pv by remember { mutableStateOf<PlayerView?>(null) }
    var hud by remember { mutableStateOf<String?>(null) }
    var hudTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(hudTick) {
        if (hudTick > 0) {
            delay(900)
            hud = null
        }
    }
    val audio = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var volume by remember { mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVol) }
    var brightness by remember {
        mutableFloatStateOf(
            (activity?.window?.attributes?.screenBrightness ?: -1f).let { if (it < 0f) 0.5f else it }
        )
    }
    val brightnessLabel = t(R.string.hud_brightness)
    val volumeLabel = t(R.string.hud_volume)

    var started by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { started = true }
    val enter by animateFloatAsState(if (started) 1f else 0f, tween(450), label = "playerIn")

    val exo = remember {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("SzPlus/1.0")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)
        // Small buffers = channels start fast.
        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 50_000, 1_500, 3_000)
            .build()
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(DefaultMediaSourceFactory(context).setDataSourceFactory(http))
            .setLoadControl(load)
            .build()
    }

    fun playAt(i: Int) {
        exo.setMediaItem(MediaItem.fromUri(item.urls[i]))
        exo.prepare()
        exo.playWhenReady = true
    }

    DisposableEffect(Unit) {
        if (dataSaver) {
            exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
                .setMaxVideoBitrate(1_500_000)
                .build()
        }
        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (urlIndex[0] + 1 < item.urls.size) {
                    urlIndex[0]++
                    playAt(urlIndex[0])
                } else {
                    failed = true
                }
            }
        }
        exo.addListener(listener)
        if (item.urls.isNotEmpty()) playAt(0) else failed = true

        // Landscape + immersive while watching
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        val controller = activity?.window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())

        onDispose {
            exo.removeListener(listener)
            exo.release()
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            controller?.show(WindowInsetsCompat.Type.systemBars())
            activity?.window?.let { w ->
                val lp = w.attributes
                lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                w.attributes = lp
            }
        }
    }

    // TV guide for live channels: refresh every minute
    LaunchedEffect(item.epgStreamId) {
        val id = item.epgStreamId ?: return@LaunchedEffect
        val a = api ?: return@LaunchedEffect
        while (true) {
            val list = runCatching { a.shortEpg(id) }.getOrDefault(emptyList())
            if (list.isNotEmpty()) epg = list
            delay(60_000)
        }
    }
    // Show the guide for a few seconds the first time it arrives, then tuck it away
    LaunchedEffect(epg.isNotEmpty()) {
        if (epg.isNotEmpty()) {
            showEpg = true
            delay(8_000)
            showEpg = false
        }
    }

    val clock by produceState(System.currentTimeMillis() / 1000) {
        while (true) {
            delay(15_000)
            value = System.currentTimeMillis() / 1000
        }
    }
    val current = epg.firstOrNull { clock >= it.start && clock < it.end }
    val upcoming = epg.firstOrNull { it.start >= (current?.end ?: clock) }

    BackHandler(true) { onClose() }

    Box(Modifier.fillMaxSize().background(Color.Black).alpha(enter)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    pv = this
                    player = exo
                    useController = true
                    controllerShowTimeoutMs = 3_500
                    keepScreenOn = true
                    setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
                    setControllerVisibilityListener(
                        PlayerView.ControllerVisibilityListener { v -> overlay = v == View.VISIBLE }
                    )
                }
            },
        )

        // Gestures: double-tap to skip 10s, swipe left side = brightness, right side = volume
        Box(
            Modifier
                .fillMaxSize()
                .padding(top = 76.dp, bottom = 120.dp)
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = {
                            pv?.let { if (it.isControllerFullyVisible) it.hideController() else it.showController() }
                        },
                        onDoubleTap = { pos ->
                            if (!exo.isCurrentMediaItemLive && exo.duration != C.TIME_UNSET) {
                                val forward = pos.x > size.width / 2
                                val target = exo.currentPosition + if (forward) 10_000 else -10_000
                                exo.seekTo(target.coerceAtLeast(0))
                                hud = if (forward) "+10s" else "-10s"
                                hudTick++
                            }
                        },
                    )
                }
                .pointerInput(Unit) {
                    detectVerticalDragGestures { change, dy ->
                        change.consume()
                        val delta = -dy / size.height * 1.4f
                        if (change.position.x < size.width / 2) {
                            brightness = (brightness + delta).coerceIn(0.02f, 1f)
                            activity?.window?.let { w ->
                                val lp = w.attributes
                                lp.screenBrightness = brightness
                                w.attributes = lp
                            }
                            hud = "$brightnessLabel ${(brightness * 100).toInt()}%"
                        } else {
                            volume = (volume + delta).coerceIn(0f, 1f)
                            audio.setStreamVolume(AudioManager.STREAM_MUSIC, (volume * maxVol).toInt(), 0)
                            hud = "$volumeLabel ${(volume * 100).toInt()}%"
                        }
                        hudTick++
                    }
                }
        )

        hud?.let {
            Text(
                it,
                Modifier.align(Alignment.Center).glass(24.dp, Color.Black.copy(0.5f))
                    .padding(horizontal = 22.dp, vertical = 12.dp),
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp,
            )
        }

        Column(Modifier.fillMaxSize().safeDrawingPadding().padding(16.dp)) {
            AnimatedVisibility(
                visible = overlay,
                enter = fadeIn() + slideInVertically { -it / 2 },
                exit = fadeOut() + slideOutVertically { -it / 2 },
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier.size(44.dp).glass(22.dp),
                    ) { Icon(Icons.Rounded.Close, contentDescription = t(R.string.close), tint = Color.White) }

                    if (epg.isNotEmpty()) {
                        IconButton(
                            onClick = { showEpg = !showEpg },
                            modifier = Modifier.size(44.dp).glass(22.dp),
                        ) { Icon(Icons.Rounded.Schedule, contentDescription = t(R.string.guide), tint = Color.White) }
                    }

                    Box(
                        Modifier.weight(1f, fill = false).height(44.dp).glass(22.dp).padding(horizontal = 16.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            item.title,
                            color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = showEpg && current != null,
                enter = fadeIn() + slideInVertically { -it / 2 },
                exit = fadeOut() + slideOutVertically { -it / 2 },
            ) {
                if (current != null) {
                    EpgCard(current, upcoming, clock, Modifier.padding(top = 12.dp))
                }
            }
        }

        if (failed) {
            Column(
                Modifier.align(Alignment.Center).glass(28.dp).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(t(R.string.player_error), color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Spacer(Modifier.height(12.dp))
                Text(
                    t(R.string.close),
                    Modifier.pressable { onClose() }
                        .background(Brand.Gradient, RoundedCornerShape(50))
                        .padding(horizontal = 24.dp, vertical = 10.dp),
                    color = Brand.OnAccent, fontWeight = FontWeight.Bold,
                )
            }
        }
    }
}

@Composable
private fun EpgCard(now: EpgEntry, next: EpgEntry?, clock: Long, modifier: Modifier = Modifier) {
    val progress = ((clock - now.start).toFloat() / (now.end - now.start).coerceAtLeast(1)).coerceIn(0f, 1f)
    Column(
        modifier.fillMaxWidth(0.6f).glass(22.dp, Color.Black.copy(0.45f)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(t(R.string.now), color = Brand.OnAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.background(Brand.Accent, RoundedCornerShape(50)).padding(horizontal = 8.dp, vertical = 2.dp))
            Text(now.title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().height(4.dp),
            color = Brand.Accent,
            trackColor = Color.White.copy(0.15f),
        )
        if (next != null) {
            Text("${t(R.string.next)}: ${next.title}", color = Color.White.copy(0.65f), fontSize = 12.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
