package com.szplus.player.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.szplus.player.AppViewModel
import com.szplus.player.R
import com.szplus.player.Section
import com.szplus.player.data.Category
import com.szplus.player.data.LiveStream
import com.szplus.player.data.Movie
import com.szplus.player.data.PlayItem
import com.szplus.player.data.Series
import com.szplus.player.data.SeriesInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private val BottomPad = 120.dp

@Composable
private fun SearchField(value: String, onChange: (String) -> Unit, hint: String) {
    TextField(
        value = value,
        onValueChange = onChange,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        singleLine = true,
        placeholder = { Text(hint, color = Color.White.copy(0.4f)) },
        leadingIcon = { Icon(Icons.Rounded.Search, null) },
        shape = RoundedCornerShape(16.dp),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = Color.White.copy(0.10f),
            unfocusedContainerColor = Color.White.copy(0.06f),
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            cursorColor = Brand.Accent,
            focusedLeadingIconColor = Brand.Accent,
            unfocusedLeadingIconColor = Color.White.copy(0.5f),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
        ),
    )
}

/** Waits until typing pauses before returning the text to filter with. */
@Composable
private fun debounced(text: String): String {
    var out by remember { mutableStateOf(text) }
    LaunchedEffect(text) {
        delay(250)
        out = text
    }
    return out
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun <T> Browser(
    section: Section<T>,
    @androidx.annotation.StringRes titleRes: Int,
    @androidx.annotation.StringRes searchRes: Int,
    grid: Boolean,
    showFavorites: Boolean,
    favorites: Set<Int>,
    idOf: (T) -> Int,
    nameOf: (T) -> String,
    categoryOf: (T) -> String?,
    row: @Composable (T) -> Unit,
    cell: @Composable (T) -> Unit,
) {
    LaunchedEffect(section) { section.load() }
    var search by remember { mutableStateOf("") }
    val query = debounced(search)
    var selected by remember { mutableStateOf<String?>(null) }
    var favOnly by remember { mutableStateOf(false) }

    // Filtering thousands of items happens on a background thread so typing and taps never freeze the screen.
    val filterActive = selected != null || favOnly || query.isNotEmpty()
    var filterResult by remember { mutableStateOf<List<T>?>(null) }
    LaunchedEffect(section.items, query, selected, favOnly, favorites, filterActive) {
        filterResult = if (filterActive) {
            withContext(Dispatchers.Default) {
                section.items.filter { s ->
                    (selected == null || categoryOf(s) == selected)
                        && (!favOnly || idOf(s) in favorites)
                        && (query.isEmpty() || nameOf(s).contains(query, ignoreCase = true))
                }
            }
        } else null
    }
    val filtered: List<T> = if (!filterActive) section.items else (filterResult ?: emptyList())
    val filterReady = !filterActive || filterResult != null

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Title(t(titleRes))
        SearchField(search, { search = it }, t(searchRes))
        Spacer(Modifier.height(10.dp))
        CategoryBar(
            categories = section.categories, selected = selected, onSelect = { selected = it },
            showFavorites = showFavorites, favoritesOnly = favOnly, onFavorites = { favOnly = it },
        )
        Spacer(Modifier.height(10.dp))

        when {
            section.loading && section.items.isEmpty() ->
                if (grid) SkeletonGrid() else SkeletonRows()
            section.error != null && section.items.isEmpty() ->
                ErrorState(section.error!!) { section.load(force = true) }
            else -> PullToRefreshBox(
                isRefreshing = section.refreshing,
                onRefresh = { section.load(force = true) },
                modifier = Modifier.fillMaxSize(),
            ) {
                if (grid) {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(104.dp),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = BottomPad),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        items(filtered) { cell(it) }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = BottomPad),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        if (filterReady && filtered.isEmpty()) item { EmptyState(favOnly) }
                        items(filtered) { row(it) }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyState(favorites: Boolean) {
    Column(
        Modifier.fillMaxWidth().padding(top = 60.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(if (favorites) Icons.Rounded.StarBorder else Icons.Rounded.Search, null,
            Modifier.size(40.dp), tint = Brand.Accent.copy(0.7f))
        Spacer(Modifier.height(8.dp))
        Text(t(if (favorites) R.string.no_favorites else R.string.no_channels),
            fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
        if (favorites) {
            Text(t(R.string.fav_hint), color = Color.White.copy(0.55f), fontSize = 13.sp,
                modifier = Modifier.padding(top = 4.dp))
        }
    }
}

// ---------- Live ----------

@Composable
fun LiveScreen(vm: AppViewModel) {
    val api = vm.api ?: return
    val section = vm.live ?: return
    Browser(
        section = section,
        titleRes = R.string.tab_live, searchRes = R.string.search_channels,
        grid = false, showFavorites = true, favorites = vm.favorites,
        idOf = { it.id }, nameOf = { it.name }, categoryOf = { it.categoryId },
        cell = {},
        row = { s ->
            val fav = s.id in vm.favorites
            Row(
                Modifier.fillMaxWidth().softCard().padding(start = 10.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(
                    Modifier.weight(1f).pressable(0.97f) {
                        vm.playing = PlayItem(s.id.toString(), s.name, api.liveUrls(s), epgStreamId = s.id)
                    },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    PosterImage(
                        s.icon,
                        Modifier.size(54.dp).clip(RoundedCornerShape(13.dp)),
                        ContentScale.Fit,
                    )
                    Spacer(Modifier.width(14.dp))
                    Text(s.name, fontWeight = FontWeight.Medium, fontSize = 16.sp, maxLines = 2,
                        overflow = TextOverflow.Ellipsis, color = Color.White)
                }
                IconButton(onClick = { vm.toggleFavorite(s.id) }) {
                    Icon(
                        if (fav) Icons.Rounded.Star else Icons.Rounded.StarBorder, null,
                        tint = if (fav) Brand.Accent else Color.White.copy(0.4f),
                    )
                }
            }
        },
    )
}

// ---------- Movies ----------

@Composable
fun MoviesScreen(vm: AppViewModel) {
    val api = vm.api ?: return
    val section = vm.movies ?: return
    Browser(
        section = section,
        titleRes = R.string.tab_movies, searchRes = R.string.search_movies,
        grid = true, showFavorites = false, favorites = emptySet(),
        idOf = { it.id }, nameOf = { it.name }, categoryOf = { it.categoryId },
        row = {},
        cell = { m ->
            PosterCard(m.name, m.icon) {
                vm.playing = PlayItem(m.id.toString(), m.name, listOf(api.movieUrl(m)))
            }
        },
    )
}

// ---------- Series ----------

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun SeriesScreen(vm: AppViewModel) {
    val section = vm.series ?: return
    var open by remember { mutableStateOf<Series?>(null) }
    BackHandler(enabled = open != null) { open = null }
    LaunchedEffect(vm.pendingSeries) {
        vm.pendingSeries?.let { open = it; vm.pendingSeries = null }
    }

    AnimatedContent(
        targetState = open,
        transitionSpec = {
            (fadeIn(tween(350)) + scaleIn(tween(350), initialScale = 0.92f)) togetherWith
                (fadeOut(tween(200)) + scaleOut(tween(200), targetScale = 1.04f))
        },
        label = "series",
    ) { current ->
        if (current == null) {
            Browser(
                section = section,
                titleRes = R.string.tab_series, searchRes = R.string.search_series,
                grid = true, showFavorites = false, favorites = emptySet(),
                idOf = { it.id }, nameOf = { it.name }, categoryOf = { it.categoryId },
                row = {},
                cell = { s -> PosterCard(s.name, s.cover) { open = s } },
            )
        } else {
            SeriesDetail(vm, current) { open = null }
        }
    }
}

@Composable
private fun SeriesDetail(vm: AppViewModel, series: Series, onBack: () -> Unit) {
    val api = vm.api ?: return
    val info by produceState<Result<SeriesInfo>?>(null, series.id) {
        value = runCatching { api.seriesInfo(series.id) }
    }
    var season by remember { mutableStateOf<String?>(null) }

    val loaded = info?.getOrNull()
    val seasonIds = remember(loaded) {
        loaded?.seasons?.keys?.sortedBy { it.toIntOrNull() ?: 0 } ?: emptyList()
    }
    val current = season ?: seasonIds.firstOrNull()
    val episodes = loaded?.seasons?.get(current) ?: emptyList()

    Box(Modifier.fillMaxSize()) {
        // Blurred poster glow behind everything
        PosterImage(
            series.cover,
            Modifier.fillMaxWidth().height(440.dp).blur(55.dp).alpha(0.5f),
        )
        Box(
            Modifier.fillMaxWidth().height(440.dp).background(
                androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.Transparent, Brand.Bg))
            )
        )

        Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState())) {
            IconButton(onClick = onBack, modifier = Modifier.padding(8.dp)) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = t(R.string.back))
            }
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                PosterImage(
                    series.cover,
                    Modifier.width(116.dp).height(174.dp).clip(RoundedCornerShape(18.dp)),
                )
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(series.name, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    val plot = loaded?.plot ?: series.plot
                    if (!plot.isNullOrBlank()) {
                        Text(plot, fontSize = 13.sp, color = Color.White.copy(0.65f), maxLines = 7,
                            overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            Spacer(Modifier.height(18.dp))

            when {
                info == null -> SkeletonRows()
                loaded == null -> ErrorState(R.string.err_network) { onBack() }
                else -> {
                    CategoryBar(
                        categories = seasonIds.map { Category(it, it) },
                        selected = current, onSelect = { season = it }, showAll = false,
                        titleFor = { t(R.string.season_n, it.id) },
                    )
                    Spacer(Modifier.height(14.dp))
                    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        episodes.forEach { ep ->
                            Row(
                                Modifier.fillMaxWidth().softCard().pressable(0.97f) {
                                    vm.playing = PlayItem(ep.id, ep.title, listOf(api.episodeUrl(ep)))
                                }.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Box(
                                    Modifier.size(34.dp).background(Brand.Gradient, CircleShape),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Text("${ep.number}", color = Brand.OnAccent, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                                Spacer(Modifier.width(14.dp))
                                Text(ep.title, Modifier.weight(1f), fontSize = 14.sp, fontWeight = FontWeight.Medium,
                                    maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Icon(Icons.Rounded.PlayArrow, null, tint = Brand.Accent)
                            }
                        }
                    }
                    Spacer(Modifier.height(BottomPad))
                }
            }
        }
    }
}
