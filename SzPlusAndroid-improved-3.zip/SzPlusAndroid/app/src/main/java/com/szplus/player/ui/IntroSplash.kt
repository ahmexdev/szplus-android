package com.szplus.player.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.szplus.player.R
import kotlinx.coroutines.launch
import kotlinx.coroutines.coroutineScope

/** Opening animation: a light ring expands, the logo springs in, then the name fades up. */
@Composable
fun IntroSplash() {
    val ring = remember { Animatable(0f) }
    val logo = remember { Animatable(0f) }
    val text = remember { Animatable(0f) }
    val glow = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        coroutineScope {
            launch { glow.animateTo(1f, tween(1400)) }
            launch { ring.animateTo(1f, tween(1500)) }
            launch { logo.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessLow)) }
            launch {
                kotlinx.coroutines.delay(650)
                text.animateTo(1f, tween(700))
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Brand.Bg), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2, size.height / 2)
            val maxR = size.maxDimension * 0.75f
            // soft glow
            drawCircle(
                Brush.radialGradient(
                    listOf(Brand.Accent.copy(0.40f * glow.value), Color.Transparent),
                    center = c, radius = maxR * 0.6f * (0.4f + 0.6f * glow.value),
                ),
                radius = maxR * 0.6f, center = c,
            )
            // expanding ring
            val r = maxR * ring.value
            drawCircle(
                Brand.Accent.copy(alpha = (1f - ring.value) * 0.8f),
                radius = r, center = c, style = Stroke(width = 3.dp.toPx()),
            )
            drawCircle(
                Brand.AccentBright.copy(alpha = (1f - ring.value) * 0.4f),
                radius = r * 0.75f, center = c, style = Stroke(width = 1.5.dp.toPx()),
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painterResource(R.drawable.logo), null,
                Modifier
                    .size(130.dp)
                    .scale(logo.value.coerceAtLeast(0.01f))
                    .graphicsLayer { rotationY = (1f - logo.value) * 140f; cameraDistance = 14f * density }
                    .alpha(logo.value.coerceIn(0f, 1f)),
            )
            Spacer(Modifier.height(18.dp))
            androidx.compose.material3.Text(
                t(R.string.brand_name),
                Modifier.alpha(text.value).graphicsLayer { translationY = (1f - text.value) * 24f },
                fontSize = 34.sp, fontWeight = FontWeight.ExtraBold,
                style = TextStyle(brush = Brand.Gradient),
            )
        }
    }
}
