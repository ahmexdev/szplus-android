package com.szplus.player

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import kotlinx.coroutines.delay
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.szplus.player.ui.Brand
import com.szplus.player.ui.LocalAppContext
import com.szplus.player.ui.IntroSplash
import com.szplus.player.ui.LoginScreen
import com.szplus.player.ui.MainScreen
import com.szplus.player.ui.SzTheme
import com.szplus.player.ui.localizedContext
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val activity = this
        setContent {
            val code = if (vm.language == "system") Locale.getDefault().language else vm.language
            val ctx = remember(code) { localizedContext(activity, code) }
            CompositionLocalProvider(
                LocalAppContext provides ctx,
                LocalLayoutDirection provides if (code == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr,
            ) {
                SzTheme {
                    var showIntro by remember { mutableStateOf(true) }
                    LaunchedEffect(Unit) {
                        delay(2200)
                        showIntro = false
                    }
                    Box(Modifier.fillMaxSize().background(Brand.Bg)) {
                        AnimatedContent(
                            targetState = vm.api != null,
                            transitionSpec = {
                                (fadeIn(tween(600)) + scaleIn(tween(600), initialScale = 0.94f)) togetherWith
                                    (fadeOut(tween(300)) + scaleOut(tween(400), targetScale = 1.06f))
                            },
                            label = "root",
                        ) { loggedIn ->
                            if (loggedIn) MainScreen(vm, activity) else LoginScreen(vm)
                        }
                        AnimatedVisibility(
                            visible = showIntro,
                            enter = fadeIn(tween(0)),
                            exit = fadeOut(tween(600)) + scaleOut(tween(600), targetScale = 1.5f),
                        ) {
                            IntroSplash()
                        }
                    }
                }
            }
        }
    }
}
