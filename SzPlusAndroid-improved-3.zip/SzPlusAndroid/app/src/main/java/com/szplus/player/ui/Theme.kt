package com.szplus.player.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object Brand {
    val Accent = Color(0xFF82E705)
    val AccentBright = Color(0xFFC6FF4D)
    val AccentDeep = Color(0xFF2E6B00)
    val Bg = Color(0xFF0A0D09)
    val Card = Color(0xFF131711)
    val OnAccent = Color(0xFF080F03)
    val Danger = Color(0xFFFF6B6B)
    val Gradient = Brush.linearGradient(listOf(AccentBright, Accent))
}

@Composable
fun SzTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Brand.Accent,
            onPrimary = Brand.OnAccent,
            background = Brand.Bg,
            onBackground = Color.White,
            surface = Brand.Card,
            onSurface = Color.White,
            secondary = Brand.AccentBright,
        ),
        content = content,
    )
}
