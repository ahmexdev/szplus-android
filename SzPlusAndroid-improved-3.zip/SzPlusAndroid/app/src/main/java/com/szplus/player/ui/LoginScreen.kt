package com.szplus.player.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.szplus.player.AppViewModel
import com.szplus.player.R

@Composable
fun LoginScreen(vm: AppViewModel) {
    var server by remember { mutableStateOf(vm.savedCredentials?.server ?: "") }
    var user by remember { mutableStateOf(vm.savedCredentials?.username ?: "") }
    var pass by remember { mutableStateOf("") }
    var showPass by remember { mutableStateOf(false) }
    var appeared by remember { mutableStateOf(false) }
    val focus = LocalFocusManager.current
    val haptic = LocalHapticFeedback.current

    LaunchedEffect(Unit) { appeared = true }

    val floatT = rememberInfiniteTransition(label = "float")
    val float by floatT.animateFloat(
        -1f, 1f, infiniteRepeatable(tween(3400), RepeatMode.Reverse), label = "f")

    val enter by animateFloatAsState(
        if (appeared) 1f else 0f,
        spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessLow), label = "enter")

    val shake = remember { Animatable(0f) }
    LaunchedEffect(vm.errorTick) {
        if (vm.errorTick > 0) {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            repeat(3) {
                shake.animateTo(10f, tween(50))
                shake.animateTo(-10f, tween(50))
            }
            shake.animateTo(0f, tween(50))
        }
    }

    val canSubmit = server.isNotBlank() && user.isNotBlank() && pass.isNotEmpty() && !vm.loggingIn
    val submit = {
        focus.clearFocus()
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        vm.login(server.trim(), user.trim(), pass)
    }

    Box(Modifier.fillMaxSize()) {
        AuroraBackground()
        Column(
            Modifier
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp)
                .widthIn(max = 480.dp)
                .align(Alignment.TopCenter),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(48.dp))

            // Logo with a breathing glow
            Box(
                Modifier.alpha(enter).scale(0.4f + 0.6f * enter),
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    Modifier
                        .size(230.dp)
                        .scale(1f + 0.12f * float)
                        .background(
                            Brush.radialGradient(listOf(Brand.Accent.copy(0.55f), Color.Transparent)),
                            CircleShape,
                        )
                )
                Image(
                    painterResource(R.drawable.logo),
                    contentDescription = null,
                    modifier = Modifier
                        .size(118.dp)
                        .offset { IntOffset(0, (7.dp.toPx() * float).toInt()) },
                )
            }

            Spacer(Modifier.height(14.dp))
            Column(
                Modifier.alpha(enter).offset { IntOffset(0, ((1f - enter) * 16.dp.toPx()).toInt()) },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    t(R.string.brand_name),
                    fontSize = 36.sp, fontWeight = FontWeight.ExtraBold,
                    style = androidx.compose.ui.text.TextStyle(brush = Brand.Gradient),
                )
                Text(t(R.string.brand_name_ar), fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
                    color = Color.White.copy(0.85f))
                Text(t(R.string.tagline), fontSize = 13.sp, color = Color.White.copy(0.55f),
                    modifier = Modifier.padding(top = 4.dp))
            }

            Spacer(Modifier.height(30.dp))

            Column(
                Modifier
                    .fillMaxWidth()
                    .alpha(enter)
                    .offset { IntOffset(shake.value.dp.roundToPx(), ((1f - enter) * 50.dp.toPx()).toInt()) }
                    .glass(32.dp)
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                AuthField(
                    value = server, onChange = { server = it }, hint = t(R.string.server_hint),
                    icon = { Icon(Icons.Rounded.Public, null) },
                    keyboardType = KeyboardType.Uri, ime = ImeAction.Next,
                    onNext = { focus.moveFocus(FocusDirection.Down) },
                )
                AuthField(
                    value = user, onChange = { user = it }, hint = t(R.string.username),
                    icon = { Icon(Icons.Rounded.Person, null) },
                    keyboardType = KeyboardType.Text, ime = ImeAction.Next,
                    onNext = { focus.moveFocus(FocusDirection.Down) },
                )
                AuthField(
                    value = pass, onChange = { pass = it }, hint = t(R.string.password),
                    icon = { Icon(Icons.Rounded.Lock, null) },
                    keyboardType = KeyboardType.Password, ime = ImeAction.Go,
                    onNext = { if (canSubmit) submit() },
                    visual = if (showPass) VisualTransformation.None else PasswordVisualTransformation(),
                    trailing = {
                        IconButton(onClick = { showPass = !showPass }) {
                            Icon(if (showPass) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, null)
                        }
                    },
                )

                vm.loginError?.let {
                    Text(t(it), color = Brand.Danger, fontSize = 13.sp)
                }

                SignInButton(enabled = canSubmit, loading = vm.loggingIn, onClick = submit)
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun AuthField(
    value: String,
    onChange: (String) -> Unit,
    hint: String,
    icon: @Composable () -> Unit,
    keyboardType: KeyboardType,
    ime: ImeAction,
    onNext: () -> Unit,
    visual: VisualTransformation = VisualTransformation.None,
    trailing: (@Composable () -> Unit)? = null,
) {
    TextField(
        value = value,
        onValueChange = onChange,
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        placeholder = { Text(hint, color = Color.White.copy(0.4f), maxLines = 1) },
        leadingIcon = icon,
        trailingIcon = trailing,
        visualTransformation = visual,
        shape = RoundedCornerShape(16.dp),
        keyboardOptions = KeyboardOptions(
            capitalization = KeyboardCapitalization.None, keyboardType = keyboardType, imeAction = ime),
        keyboardActions = KeyboardActions(onNext = { onNext() }, onGo = { onNext() }),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = Color.White.copy(0.10f),
            unfocusedContainerColor = Color.White.copy(0.06f),
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            cursorColor = Brand.Accent,
            focusedLeadingIconColor = Brand.Accent,
            unfocusedLeadingIconColor = Color.White.copy(0.5f),
            focusedTrailingIconColor = Color.White.copy(0.7f),
            unfocusedTrailingIconColor = Color.White.copy(0.5f),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
        ),
    )
}

@Composable
private fun SignInButton(enabled: Boolean, loading: Boolean, onClick: () -> Unit) {
    val alpha by animateFloatAsState(if (enabled || loading) 1f else 0.45f, label = "btnalpha")
    val shineT = rememberInfiniteTransition(label = "shine")
    val p by shineT.animateFloat(
        0f, 1f, infiniteRepeatable(tween(3200)), label = "p")
    Box(
        Modifier
            .fillMaxWidth()
            .height(56.dp)
            .alpha(alpha)
            .clip(RoundedCornerShape(18.dp))
            .background(Brand.Gradient)
            .drawWithContent {
                drawContent()
                if (enabled) {
                    val w = size.width
                    val x = -w * 0.4f + p * w * 1.8f
                    drawRect(
                        Brush.horizontalGradient(
                            listOf(Color.Transparent, Color.White.copy(0.38f), Color.Transparent),
                            startX = x, endX = x + w * 0.35f,
                        ),
                    )
                }
            }
            .pressable(0.96f) { if (enabled) onClick() },
        contentAlignment = Alignment.Center,
    ) {
        if (loading) {
            CircularProgressIndicator(Modifier.size(24.dp), color = Brand.OnAccent, strokeWidth = 2.5.dp)
        } else {
            Text(t(R.string.sign_in), color = Brand.OnAccent, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        }
    }
}
