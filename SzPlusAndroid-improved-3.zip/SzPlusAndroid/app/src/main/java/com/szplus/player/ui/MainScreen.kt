package com.szplus.player.ui

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.annotation.StringRes
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LiveTv
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.szplus.player.AppViewModel
import com.szplus.player.R

enum class AppTab(@StringRes val title: Int, val icon: ImageVector) {
    Home(R.string.tab_home, Icons.Rounded.Home),
    Live(R.string.tab_live, Icons.Rounded.LiveTv),
    Movies(R.string.tab_movies, Icons.Rounded.Movie),
    Series(R.string.tab_series, Icons.Rounded.VideoLibrary),
    Account(R.string.tab_account, Icons.Rounded.Person),
}

@Composable
fun MainScreen(vm: AppViewModel, activity: Activity?) {
    var tabIndex by rememberSaveable { mutableIntStateOf(0) }
    val tabs = AppTab.entries

    LaunchedEffect(vm.pendingSeries) {
        if (vm.pendingSeries != null) tabIndex = AppTab.Series.ordinal
    }

    Box(Modifier.fillMaxSize().background(Brand.Bg)) {
        AnimatedContent(
            targetState = tabIndex,
            transitionSpec = {
                (fadeIn(tween(380)) + scaleIn(tween(380), initialScale = 0.94f)) togetherWith
                    (fadeOut(tween(220)) + scaleOut(tween(300), targetScale = 1.06f))
            },
            label = "tabs",
        ) { i ->
            when (tabs[i]) {
                AppTab.Home -> HomeScreen(vm)
                AppTab.Live -> LiveScreen(vm)
                AppTab.Movies -> MoviesScreen(vm)
                AppTab.Series -> SeriesScreen(vm)
                AppTab.Account -> AccountScreen(vm)
            }
        }

        GlassTabBar(
            selected = tabIndex,
            onSelect = { tabIndex = it },
            modifier = Modifier.align(Alignment.BottomCenter),
        )

        val item = vm.playing
        if (item != null) {
            BackHandler(true) { vm.playing = null }
            PlayerScreen(
                item = item,
                api = vm.api,
                dataSaver = vm.dataSaver,
                activity = activity,
                onClose = { vm.playing = null },
            )
        }
    }
}

@Composable
private fun GlassTabBar(selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val tabs = AppTab.entries
    BoxWithConstraints(
        modifier
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 14.dp)
            .fillMaxWidth()
            .glass(34.dp, Color(0xFF14180F).copy(alpha = 0.86f))
            .padding(6.dp)
    ) {
        val itemW = maxWidth / tabs.size
        val lensX by animateDpAsState(
            itemW * selected,
            spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMediumLow),
            label = "lens",
        )
        // Sliding lens behind the selected tab
        Box(
            Modifier
                .offset(x = lensX)
                .width(itemW)
                .height(56.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(Brand.Accent.copy(alpha = 0.20f))
                .border(0.8.dp, Brand.Accent.copy(alpha = 0.45f), RoundedCornerShape(28.dp))
        )
        Row(Modifier.fillMaxWidth()) {
            tabs.forEachIndexed { i, tab ->
                val tint by animateColorAsState(
                    if (i == selected) Brand.Accent else Color.White.copy(alpha = 0.6f), label = "tint")
                Column(
                    Modifier
                        .weight(1f)
                        .height(56.dp)
                        .pressable(0.92f) { onSelect(i) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
                ) {
                    Icon(tab.icon, null, Modifier.size(24.dp), tint = tint)
                    Text(t(tab.title), color = tint, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
            }
        }
    }
}
