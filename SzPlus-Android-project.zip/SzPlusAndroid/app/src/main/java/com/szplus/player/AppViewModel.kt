package com.szplus.player

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.szplus.player.data.AccountInfo
import com.szplus.player.data.ApiException
import com.szplus.player.data.Category
import com.szplus.player.data.Credentials
import com.szplus.player.data.LiveStream
import com.szplus.player.data.Movie
import com.szplus.player.data.PlayItem
import com.szplus.player.data.Series
import com.szplus.player.data.XtreamApi
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import java.io.IOException

fun errorRes(e: Throwable): Int = when (e) {
    is ApiException -> e.resId
    is IOException -> R.string.err_network
    else -> R.string.err_generic
}

/** One browsable list (live / movies / series). Shows the saved copy first, then refreshes. */
class Section<T>(
    private val scope: CoroutineScope,
    private val cached: suspend () -> Pair<List<Category>, List<T>>?,
    private val fetch: suspend () -> Pair<List<Category>, List<T>>,
) {
    var items by mutableStateOf<List<T>>(emptyList())
        private set
    var categories by mutableStateOf<List<Category>>(emptyList())
        private set
    var loading by mutableStateOf(true)
        private set
    var refreshing by mutableStateOf(false)
        private set
    var error by mutableStateOf<Int?>(null)
        private set

    private var started = false

    fun load(force: Boolean = false) {
        if (started && !force) return
        started = true
        scope.launch {
            error = null
            if (force) refreshing = true
            if (items.isEmpty()) {
                val saved = runCatching { cached() }.getOrNull()
                if (saved != null && saved.second.isNotEmpty()) {
                    categories = saved.first
                    items = saved.second
                    loading = false
                } else {
                    loading = true
                }
            }
            try {
                val fresh = fetch()
                categories = fresh.first
                items = fresh.second
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (items.isEmpty()) error = errorRes(e)
            }
            loading = false
            refreshing = false
        }
    }
}

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("szplus", Context.MODE_PRIVATE)
    private val cacheDir = app.cacheDir

    var api by mutableStateOf<XtreamApi?>(null)
        private set
    var live by mutableStateOf<Section<LiveStream>?>(null)
        private set
    var movies by mutableStateOf<Section<Movie>?>(null)
        private set
    var series by mutableStateOf<Section<Series>?>(null)
        private set

    var account by mutableStateOf<AccountInfo?>(null)
        private set
    var loggingIn by mutableStateOf(false)
        private set
    var loginError by mutableStateOf<Int?>(null)
        private set
    /** Bumps on every failed login so the form can shake. */
    var errorTick by mutableIntStateOf(0)
        private set

    var language by mutableStateOf(prefs.getString("lang", "system") ?: "system")
        private set
    var dataSaver by mutableStateOf(prefs.getBoolean("saver", false))
        private set
    var favorites by mutableStateOf<Set<Int>>(
        (prefs.getStringSet("fav", emptySet()) ?: emptySet()).mapNotNull { it.toIntOrNull() }.toSet()
    )
        private set

    /** A series picked on Home; the Series tab opens it. */
    var pendingSeries by mutableStateOf<Series?>(null)

    /** The video being played right now (null = none). */
    var playing by mutableStateOf<PlayItem?>(null)

    val savedCredentials: Credentials?
        get() {
            val s = prefs.getString("server", null) ?: return null
            val u = prefs.getString("user", null) ?: return null
            val p = prefs.getString("pass", null) ?: return null
            return Credentials(s, u, p)
        }

    init {
        savedCredentials?.let { start(it) }
    }

    private fun start(c: Credentials) {
        val a = XtreamApi(c, cacheDir)
        live = Section(viewModelScope, { a.cachedLive() }, { a.live() })
        movies = Section(viewModelScope, { a.cachedMovies() }, { a.movies() })
        series = Section(viewModelScope, { a.cachedSeries() }, { a.series() })
        api = a
        refreshAccount()
    }

    fun login(server: String, user: String, pass: String) {
        if (loggingIn) return
        loggingIn = true
        loginError = null
        viewModelScope.launch {
            val creds = Credentials(server, user, pass)
            val candidate = XtreamApi(creds, cacheDir)
            try {
                val info = candidate.login()
                prefs.edit()
                    .putString("server", candidate.base)
                    .putString("user", user)
                    .putString("pass", pass)
                    .apply()
                account = info
                start(Credentials(candidate.base, user, pass))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                loginError = errorRes(e)
                errorTick++
            }
            loggingIn = false
        }
    }

    fun refreshAccount() {
        val a = api ?: return
        viewModelScope.launch {
            try { account = a.accountInfo() } catch (e: CancellationException) { throw e } catch (_: Exception) {}
        }
    }

    fun logout() {
        api?.clearCache()
        prefs.edit().remove("server").remove("user").remove("pass").apply()
        playing = null
        account = null
        loginError = null
        api = null
        live = null
        movies = null
        series = null
    }

    fun toggleFavorite(id: Int) {
        favorites = if (id in favorites) favorites - id else favorites + id
        prefs.edit().putStringSet("fav", favorites.map { it.toString() }.toSet()).apply()
    }

    fun setLanguage(code: String) {
        language = code
        prefs.edit().putString("lang", code).apply()
    }

    fun setDataSaver(on: Boolean) {
        dataSaver = on
        prefs.edit().putBoolean("saver", on).apply()
    }
}
