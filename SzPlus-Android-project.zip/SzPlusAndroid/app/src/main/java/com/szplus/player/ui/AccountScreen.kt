package com.szplus.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.szplus.player.AppViewModel
import com.szplus.player.R
import java.text.DateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AccountScreen(vm: AppViewModel) {
    LaunchedEffect(Unit) { vm.refreshAccount() }
    val creds = vm.api?.creds
    val account = vm.account
    var confirm by remember { mutableStateOf(false) }
    val langCode = if (vm.language == "system") Locale.getDefault().language else vm.language

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Title(t(R.string.account_title))

        // Profile
        Row(
            Modifier.padding(horizontal = 16.dp).fillMaxWidth().softCard(24.dp).padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(56.dp).background(Brand.Gradient, CircleShape), contentAlignment = Alignment.Center) {
                Text(
                    (creds?.username?.firstOrNull() ?: 'S').uppercaseChar().toString(),
                    color = Brand.OnAccent, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp,
                )
            }
            Spacer(Modifier.width(16.dp))
            Column {
                Text(creds?.username ?: "", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(
                    (creds?.server ?: "").removePrefix("http://").removePrefix("https://"),
                    color = Color.White.copy(0.5f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        }

        // Subscription
        Column(
            Modifier.padding(horizontal = 16.dp).fillMaxWidth().softCard(24.dp).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            SectionLabel(t(R.string.subscription))
            val status = account?.status ?: "…"
            val active = status.equals("active", ignoreCase = true)
            InfoRow(t(R.string.status)) {
                Text(
                    if (active) t(R.string.active) else status,
                    color = if (active) Brand.OnAccent else Color.White,
                    fontWeight = FontWeight.Bold, fontSize = 13.sp,
                    modifier = Modifier
                        .background(if (active) Brand.Accent else Brand.Danger.copy(0.35f), RoundedCornerShape(50))
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                )
            }
            InfoRow(t(R.string.expires)) {
                val exp = account?.expiresAt
                Text(
                    if (exp == null) t(R.string.unlimited)
                    else DateFormat.getDateInstance(DateFormat.MEDIUM, Locale(langCode)).format(Date(exp * 1000)),
                    fontWeight = FontWeight.SemiBold,
                )
            }
            InfoRow(t(R.string.connections)) {
                val max = account?.maxConnections
                val act = account?.activeConnections ?: "0"
                Text(if (max != null) "$act / $max" else act, fontWeight = FontWeight.SemiBold)
            }
        }

        // Settings
        Column(
            Modifier.padding(horizontal = 16.dp).fillMaxWidth().softCard(24.dp).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            SectionLabel(t(R.string.settings))
            Text(t(R.string.language), fontWeight = FontWeight.SemiBold)
            Row(
                Modifier.fillMaxWidth().background(Color.White.copy(0.06f), RoundedCornerShape(14.dp)).padding(4.dp),
            ) {
                listOf(
                    "system" to R.string.lang_system,
                    "en" to R.string.lang_en,
                    "ar" to R.string.lang_ar,
                ).forEach { (code, label) ->
                    val on = vm.language == code
                    Box(
                        Modifier.weight(1f)
                            .background(if (on) Brand.Accent else Color.Transparent, RoundedCornerShape(11.dp))
                            .pressable(0.96f) { vm.setLanguage(code) }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(t(label), color = if (on) Brand.OnAccent else Color.White.copy(0.8f),
                            fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(t(R.string.data_saver), fontWeight = FontWeight.SemiBold)
                    Text(t(R.string.data_saver_hint), color = Color.White.copy(0.5f), fontSize = 12.sp)
                }
                Switch(
                    checked = vm.dataSaver,
                    onCheckedChange = { vm.setDataSaver(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Brand.OnAccent, checkedTrackColor = Brand.Accent),
                )
            }
        }

        // Sign out
        Row(
            Modifier.padding(horizontal = 16.dp).fillMaxWidth()
                .background(Brand.Danger.copy(0.14f), RoundedCornerShape(20.dp))
                .pressable(0.97f) { confirm = true }
                .padding(16.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.AutoMirrored.Rounded.Logout, null, tint = Brand.Danger)
            Spacer(Modifier.width(10.dp))
            Text(t(R.string.sign_out), color = Brand.Danger, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(120.dp))
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text(t(R.string.sign_out)) },
            text = { Text(t(R.string.sign_out_confirm)) },
            confirmButton = {
                TextButton(onClick = { confirm = false; vm.logout() }) {
                    Text(t(R.string.sign_out), color = Brand.Danger)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirm = false }) { Text(t(R.string.cancel)) }
            },
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, color = Brand.Accent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
}

@Composable
private fun InfoRow(label: String, value: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = Color.White.copy(0.6f))
        value()
    }
}
