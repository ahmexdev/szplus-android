package com.szplus.player.data

import android.util.Base64
import com.szplus.player.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest

class ApiException(val resId: Int) : IOException("api error")

private fun JSONObject.str(key: String): String? {
    if (!has(key) || isNull(key)) return null
    val s = optString(key, "")
    return if (s.isBlank() || s == "null") null else s
}

class XtreamApi(val creds: Credentials, private val cacheDir: File) {

    val base: String = normalize(creds.server)

    private val keyPrefix: String = sha("${base}|${creds.username}").take(16)

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    // ---------- networking ----------

    private suspend fun fetchText(action: String?, extra: String = ""): String = withContext(Dispatchers.IO) {
        var url = "$base/player_api.php?username=${enc(creds.username)}&password=${enc(creds.password)}"
        if (action != null) url += "&action=$action"
        url += extra
        var last: Exception? = null
        repeat(2) { attempt ->
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                try {
                    conn.connectTimeout = 15_000
                    conn.readTimeout = 60_000
                    conn.instanceFollowRedirects = true
                    conn.setRequestProperty("User-Agent", "SzPlus/1.0")
                    conn.setRequestProperty("Accept", "application/json")
                    val code = conn.responseCode
                    if (code == 401 || code == 403) throw ApiException(R.string.err_invalid)
                    if (code !in 200..299) throw IOException("HTTP $code")
                    return@withContext conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                } finally {
                    conn.disconnect()
                }
            } catch (e: ApiException) {
                throw e
            } catch (e: Exception) {
                last = e
                if (attempt == 0) kotlinx.coroutines.delay(600)
            }
        }
        throw last ?: IOException("failed")
    }

    // ---------- disk cache (raw JSON, per account) ----------

    private fun cacheFile(key: String) = File(cacheDir, "xt_${keyPrefix}_$key.json")

    private suspend fun <T> fetchCached(key: String, action: String, parse: (String) -> T): T {
        val text = fetchText(action)
        val parsed = withContext(Dispatchers.Default) { parse(text) }
        withContext(Dispatchers.IO) { runCatching { cacheFile(key).writeText(text) } }
        return parsed
    }

    private suspend fun <T> readCached(key: String, parse: (String) -> T): T? = withContext(Dispatchers.IO) {
        val f = cacheFile(key)
        if (!f.exists()) return@withContext null
        runCatching { parse(f.readText()) }.getOrNull()
    }

    fun clearCache() {
        cacheDir.listFiles()?.forEach { if (it.name.startsWith("xt_${keyPrefix}_")) it.delete() }
    }

    // ---------- account ----------

    suspend fun login(): AccountInfo {
        val text = fetchText(null)
        val root = try { JSONObject(text) } catch (e: Exception) { throw ApiException(R.string.err_network) }
        val user = root.optJSONObject("user_info") ?: throw ApiException(R.string.err_invalid)
        val auth = user.str("auth")
        if (auth == null || auth == "0") throw ApiException(R.string.err_invalid)
        return parseAccount(user)
    }

    suspend fun accountInfo(): AccountInfo {
        val user = JSONObject(fetchText(null)).optJSONObject("user_info") ?: throw ApiException(R.string.err_invalid)
        return parseAccount(user)
    }

    private fun parseAccount(u: JSONObject) = AccountInfo(
        status = u.str("status") ?: "Active",
        expiresAt = u.str("exp_date")?.toLongOrNull()?.takeIf { it > 0 },
        maxConnections = u.str("max_connections"),
        activeConnections = u.str("active_cons"),
    )

    // ---------- EPG ----------

    suspend fun shortEpg(streamId: Int, limit: Int = 4): List<EpgEntry> {
        val text = fetchText("get_short_epg", "&stream_id=$streamId&limit=$limit")
        return withContext(Dispatchers.Default) {
            val arr = JSONObject(text).optJSONArray("epg_listings") ?: return@withContext emptyList()
            val out = ArrayList<EpgEntry>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val start = o.str("start_timestamp")?.toLongOrNull() ?: continue
                val end = o.str("stop_timestamp")?.toLongOrNull() ?: continue
                val raw = o.str("title") ?: continue
                val title = runCatching { String(Base64.decode(raw, Base64.DEFAULT), Charsets.UTF_8) }
                    .getOrDefault(raw).trim()
                if (title.isNotEmpty()) out += EpgEntry(title, start, end)
            }
            out.sortedBy { it.start }
        }
    }

    // ---------- Live ----------

    private fun parseCats(text: String): List<Category> {
        val arr = JSONArray(text)
        val out = ArrayList<Category>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.str("category_id") ?: continue
            out += Category(id, o.str("category_name") ?: id)
        }
        return out
    }

    private fun parseLive(text: String): List<LiveStream> {
        val arr = JSONArray(text)
        val out = ArrayList<LiveStream>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.str("stream_id")?.toIntOrNull() ?: continue
            out += LiveStream(id, o.str("name") ?: "", o.str("stream_icon"), o.str("category_id"))
        }
        return out
    }

    private fun parseMovies(text: String): List<Movie> {
        val arr = JSONArray(text)
        val out = ArrayList<Movie>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.str("stream_id")?.toIntOrNull() ?: continue
            out += Movie(id, o.str("name") ?: "", o.str("stream_icon"), o.str("category_id"),
                o.str("container_extension") ?: "mp4")
        }
        return out
    }

    private fun parseSeries(text: String): List<Series> {
        val arr = JSONArray(text)
        val out = ArrayList<Series>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.str("series_id")?.toIntOrNull() ?: continue
            out += Series(id, o.str("name") ?: "", o.str("cover"), o.str("category_id"), o.str("plot"))
        }
        return out
    }

    suspend fun live(): Pair<List<Category>, List<LiveStream>> = coroutineScope {
        val c = async { fetchCached("live_cats", "get_live_categories", this::parseCats) }
        val s = async { fetchCached("live", "get_live_streams", this::parseLive) }
        c.await() to s.await()
    }

    suspend fun cachedLive(): Pair<List<Category>, List<LiveStream>>? {
        val s = readCached("live", this::parseLive) ?: return null
        return (readCached("live_cats", this::parseCats) ?: emptyList()) to s
    }

    suspend fun movies(): Pair<List<Category>, List<Movie>> = coroutineScope {
        val c = async { fetchCached("vod_cats", "get_vod_categories", this::parseCats) }
        val s = async { fetchCached("vod", "get_vod_streams", this::parseMovies) }
        c.await() to s.await()
    }

    suspend fun cachedMovies(): Pair<List<Category>, List<Movie>>? {
        val s = readCached("vod", this::parseMovies) ?: return null
        return (readCached("vod_cats", this::parseCats) ?: emptyList()) to s
    }

    suspend fun series(): Pair<List<Category>, List<Series>> = coroutineScope {
        val c = async { fetchCached("series_cats", "get_series_categories", this::parseCats) }
        val s = async { fetchCached("series", "get_series", this::parseSeries) }
        c.await() to s.await()
    }

    suspend fun cachedSeries(): Pair<List<Category>, List<Series>>? {
        val s = readCached("series", this::parseSeries) ?: return null
        return (readCached("series_cats", this::parseCats) ?: emptyList()) to s
    }

    suspend fun seriesInfo(id: Int): SeriesInfo {
        val text = fetchText("get_series_info", "&series_id=$id")
        return withContext(Dispatchers.Default) {
            val root = JSONObject(text)
            val plot = root.optJSONObject("info")?.str("plot")
            val seasons = LinkedHashMap<String, List<Episode>>()
            fun parseList(arr: JSONArray?): List<Episode> {
                val out = ArrayList<Episode>()
                if (arr == null) return out
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val epId = o.str("id") ?: continue
                    out += Episode(
                        id = epId,
                        title = o.str("title") ?: "Episode ${i + 1}",
                        number = o.str("episode_num")?.toIntOrNull() ?: (i + 1),
                        ext = o.str("container_extension") ?: "mp4",
                    )
                }
                return out.sortedBy { it.number }
            }
            val eps = root.opt("episodes")
            when (eps) {
                is JSONObject -> {
                    val keys = eps.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        seasons[k] = parseList(eps.optJSONArray(k))
                    }
                }
                is JSONArray -> {
                    for (i in 0 until eps.length()) {
                        val inner = eps.optJSONArray(i)
                        if (inner != null) seasons[(i + 1).toString()] = parseList(inner)
                    }
                }
            }
            SeriesInfo(plot, seasons.filterValues { it.isNotEmpty() })
        }
    }

    // ---------- stream URLs ----------

    private val auth get() = "${enc(creds.username)}/${enc(creds.password)}"

    fun liveUrls(s: LiveStream): List<String> =
        listOf("$base/live/$auth/${s.id}.m3u8", "$base/live/$auth/${s.id}.ts")

    fun movieUrl(m: Movie): String = "$base/movie/$auth/${m.id}.${m.ext}"

    fun episodeUrl(e: Episode): String = "$base/series/$auth/${e.id}.${e.ext}"

    companion object {
        fun normalize(raw: String): String {
            var s = raw.trim()
            if (!s.startsWith("http://", true) && !s.startsWith("https://", true)) s = "http://$s"
            s = s.substringBefore("/player_api.php").substringBefore("/get.php")
            return s.trimEnd('/')
        }

        private fun sha(s: String): String =
            MessageDigest.getInstance("SHA-256").digest(s.toByteArray())
                .joinToString("") { "%02x".format(it) }
    }
}
