package com.szplus.player.ui

import android.content.Context
import android.content.res.Configuration
import androidx.annotation.StringRes
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import java.util.Locale

// ---------- language ----------

val LocalAppContext = compositionLocalOf<Context> { error("no context") }

fun localizedContext(base: Context, code: String): Context {
    val cfg = Configuration(base.resources.configuration)
    cfg.setLocale(Locale(code))
    return base.createConfigurationContext(cfg)
}

@Composable
fun t(@StringRes id: Int): String = LocalAppContext.current.getString(id)

@Composable
fun t(@StringRes id: Int, vararg args: Any): String = LocalAppContext.current.getString(id, *args)

// ---------- glass + motion ----------

/** Frosted-glass card: soft white tint with a bright rim. */
fun Modifier.glass(radius: Dp = 24.dp, tint: Color = Color.White.copy(alpha = 0.07f)): Modifier {
    val shape = RoundedCornerShape(radius)
    return this
        .clip(shape)
        .background(tint)
        .border(
            0.8.dp,
            Brush.linearGradient(listOf(Color.White.copy(0.28f), Color.White.copy(0.04f), Color.White.copy(0.12f))),
            shape,
        )
}

fun Modifier.softCard(radius: Dp = 20.dp): Modifier = this
    .clip(RoundedCornerShape(radius))
    .background(Brand.Card)
    .border(0.7.dp, Color.White.copy(0.07f), RoundedCornerShape(radius))

/** Tap target that squishes slightly when pressed. */
@Composable
fun Modifier.pressable(scaleTo: Float = 0.96f, onClick: () -> Unit): Modifier {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) scaleTo else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "press",
    )
    return this
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .clickable(interactionSource = source, indication = null, onClick = onClick)
}

@Composable
fun Modifier.shimmer(): Modifier {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val x by transition.animateFloat(
        initialValue = -400f, targetValue = 1200f,
        animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing)),
        label = "x",
    )
    return this.background(
        Brush.linearGradient(
            listOf(Color.White.copy(0.04f), Color.White.copy(0.13f), Color.White.copy(0.04f)),
            start = Offset(x, 0f), end = Offset(x + 400f, 200f),
        )
    )
}

/** Slowly drifting lime glow behind the login screen. */
@Composable
fun AuroraBackground(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "aurora")
    val a by transition.animateFloat(
        0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    val b by transition.animateFloat(
        1f, 0f, infiniteRepeatable(tween(13000, easing = LinearEasing), RepeatMode.Reverse), label = "b")
    Canvas(modifier.fillMaxSize().background(Brand.Bg)) {
        val w = size.width
        val h = size.height
        fun blob(cx: Float, cy: Float, r: Float, alpha: Float) {
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Brand.Accent.copy(alpha), Color.Transparent), center = Offset(cx, cy), radius = r),
                radius = r, center = Offset(cx, cy),
            )
        }
        blob(w * (0.15f + 0.5f * a), h * (0.12f + 0.12f * b), w * 0.9f, 0.30f)
        blob(w * (0.9f - 0.5f * b), h * (0.55f + 0.1f * a), w * 0.8f, 0.20f)
        blob(w * (0.2f + 0.3f * b), h * (0.95f - 0.15f * a), w * 0.9f, 0.24f)
    }
}

// ---------- images ----------

@Composable
fun PosterImage(
    url: String?,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
) {
    Box(modifier.background(Color.White.copy(0.05f))) {
        if (!url.isNullOrBlank()) {
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current).data(url).crossfade(150).build(),
                contentDescription = null,
                contentScale = contentScale,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

@Composable
fun PosterCard(title: String, imageUrl: String?, onClick: () -> Unit) {
    Column(Modifier.pressable(0.94f, onClick)) {
        PosterImage(
            imageUrl,
            Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f)
                .clip(RoundedCornerShape(16.dp))
                .border(0.8.dp, Color.White.copy(0.14f), RoundedCornerShape(16.dp)),
        )
        Text(
            title,
            Modifier.padding(top = 6.dp, start = 2.dp, end = 2.dp),
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            color = Color.White.copy(0.9f),
        )
    }
}

// ---------- chips ----------

@Composable
fun Chip(label: String, selected: Boolean, leadingStar: Boolean = false, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) Brand.Accent else Color.White.copy(0.08f), label = "chipbg")
    val fg by animateColorAsState(if (selected) Brand.OnAccent else Color.White.copy(0.85f), label = "chipfg")
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .pressable(0.94f, onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (leadingStar) {
            Icon(Icons.Rounded.Star, null, Modifier.size(15.dp).padding(end = 0.dp), tint = fg)
            Spacer(Modifier.size(5.dp))
        }
        Text(label, color = fg, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
fun CategoryBar(
    categories: List<com.szplus.player.data.Category>,
    selected: String?,
    onSelect: (String?) -> Unit,
    showAll: Boolean = true,
    showFavorites: Boolean = false,
    favoritesOnly: Boolean = false,
    onFavorites: (Boolean) -> Unit = {},
    titleFor: (com.szplus.player.data.Category) -> String = { it.name },
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (showAll) {
            item {
                Chip(t(com.szplus.player.R.string.all), selected == null && !favoritesOnly) {
                    onSelect(null); onFavorites(false)
                }
            }
        }
        if (showFavorites) {
            item {
                Chip(t(com.szplus.player.R.string.favorites), favoritesOnly, leadingStar = true) {
                    onFavorites(!favoritesOnly)
                }
            }
        }
        items(categories) { c ->
            Chip(titleFor(c), selected == c.id && !favoritesOnly) {
                onSelect(c.id); onFavorites(false)
            }
        }
    }
}

// ---------- loading / error ----------

@Composable
fun SkeletonRows(modifier: Modifier = Modifier) {
    Column(modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        repeat(8) {
            Box(Modifier.fillMaxWidth().height(70.dp).clip(RoundedCornerShape(20.dp)).shimmer())
        }
    }
}

@Composable
fun SkeletonGrid(modifier: Modifier = Modifier) {
    Column(modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        repeat(3) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                repeat(3) {
                    Box(
                        Modifier.weight(1f).aspectRatio(2f / 3f)
                            .clip(RoundedCornerShape(16.dp)).shimmer()
                    )
                }
            }
        }
    }
}

@Composable
fun ErrorState(@StringRes message: Int, onRetry: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(t(message), textAlign = TextAlign.Center, color = Color.White.copy(0.8f))
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = onRetry,
            colors = ButtonDefaults.buttonColors(containerColor = Brand.Accent, contentColor = Brand.OnAccent),
        ) { Text(t(com.szplus.player.R.string.retry), fontWeight = FontWeight.Bold) }
    }
}

@Composable
fun Title(text: String) {
    Text(
        text,
        Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
        style = MaterialTheme.typography.headlineMedium,
        fontWeight = FontWeight.ExtraBold,
        color = Color.White,
    )
}
