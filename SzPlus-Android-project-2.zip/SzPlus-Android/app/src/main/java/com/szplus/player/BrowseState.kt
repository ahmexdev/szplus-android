package com.szplus.player

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.PullToRefreshDefaults
import androidx.compose.material3.PullToRefreshBox
import androidx.compose.material3.rememberPullToRefreshState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlin.coroutines.cancellation.CancellationException

/** Height the floating tab bar takes up, so lists can scroll clear of it. */
val LocalBottomInset = compositionLocalOf<Dp> { 100.dp }

/**
 * Loads a list the fast way: show the saved copy instantly, then refresh quietly in the background.
 */
@Stable
class BrowseState<T> {
    var categories by mutableStateOf<List<Category>>(emptyList())
    var items by mutableStateOf<List<T>>(emptyList())
    var loading by mutableStateOf(true)
    var refreshing by mutableStateOf(false)
    var error by mutableStateOf<ApiError?>(null)

    suspend fun load(
        cachedItems: suspend () -> List<T>?,
        cachedCategories: suspend () -> List<Category>?,
        fetchItems: suspend () -> List<T>,
        fetchCategories: suspend () -> List<Category>,
    ) {
        error = null
        if (items.isEmpty()) {
            val saved = cachedItems()
            if (!saved.isNullOrEmpty()) {
                categories = cachedCategories() ?: emptyList()
                items = saved
                loading = false
            } else {
                loading = true
            }
        }
        try {
            coroutineScope {
                val c = async { fetchCategories() }
                val i = async { fetchItems() }
                val newCategories = c.await()
                val newItems = i.await()
                categories = newCategories
                items = newItems
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: ApiError) {
            if (items.isEmpty()) error = e
        } catch (e: Exception) {
            if (items.isEmpty()) error = ApiError.Unreachable
        }
        loading = false
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RefreshBox(
    refreshing: Boolean,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    val state = rememberPullToRefreshState()
    PullToRefreshBox(
        isRefreshing = refreshing,
        onRefresh = onRefresh,
        modifier = modifier,
        state = state,
        indicator = {
            PullToRefreshDefaults.Indicator(
                state = state,
                isRefreshing = refreshing,
                modifier = Modifier.align(Alignment.TopCenter),
                containerColor = AppConfig.Card,
                color = AppConfig.Accent,
            )
        },
        content = content,
    )
}
