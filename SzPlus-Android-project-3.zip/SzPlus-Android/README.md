# Sz plus (Android)

Android version of the Sz plus player. Same idea as the iOS app: each client enters **server URL, username and password**, then gets Live TV, Movies and Series from their Xtream Codes server.

Built with Kotlin + Jetpack Compose, Media3 (ExoPlayer) for playback, Coil for images.

## Features

- Sz plus lime (#82e705) theme, animated aurora background, glass cards, floating glass tab bar with a sliding highlight, haptics.
- **Fast:** channel, movie and series lists are saved on the phone and open instantly, then refresh in the background. Pull down to refresh. Posters and logos are cached. Failed requests retry once.
- **TV guide:** open a live channel and the player shows what is on now and next, with a progress bar (needs EPG data on the server). The TV button at the top brings it back.
- **Arabic and English:** follows the phone's language, or switch in Account > Language. Arabic uses a right-to-left layout.
- **Account page:** subscription status, expiry date, connections, language, and Data saver (caps video quality at about 1.5 Mbps on streams that offer several qualities).
- Live channels try HLS (`.m3u8`) first, then `.ts`. Favorites for live channels.

## 1. Brand it

| What | Where |
|---|---|
| App name, colors, optional pre-filled server URL | `app/src/main/java/com/szplus/player/Config.kt` |
| App name (home screen) | `app/src/main/res/values/strings.xml` (`app_name`) |
| In-app logo (transparent PNG) | `app/src/main/res/drawable-nodpi/app_logo.png` |
| Home-screen icon | `res/mipmap-*/ic_launcher*.png` (older phones) and `drawable-nodpi/ic_launcher_foreground.png` + `values/colors.xml` (`ic_launcher_background`) |
| Package name | `app/build.gradle.kts` (`applicationId`) |
| Arabic wording | `app/src/main/res/values-ar/strings.xml` |

Set `DEFAULT_SERVER_URL` in `Config.kt` to pre-fill your host for every client.

## 2. Get the .apk (no Android Studio needed)

1. Upload everything in this folder to a GitHub repository (keep the `.github` folder).
2. Open **Actions**, pick **Build APK**, click **Run workflow**. It also runs on every commit.
3. After a few minutes, download the **SzPlus-apk** artifact. Unzip it to get `app-release.apk`.

The APK is signed with the standard debug key, so it installs directly on any phone (allow "install unknown apps"). For the Play Store, or if your external app store needs your own signature, replace the `signingConfig` line in `app/build.gradle.kts` with your own keystore.

If a build fails, open the failed step and look for lines starting with `e:` (Kotlin errors).

## 3. Build in Android Studio instead

Open this folder in Android Studio (Ladybug or newer), let it sync, then **Build > Build APK(s)**. Android Studio will create the Gradle wrapper for you.

## Notes

- Android 7.0 (API 24) or later, phones and tablets.
- Uses the standard Xtream API (`player_api.php`) and `get_short_epg` for the guide.
- Cleartext HTTP is allowed because most IPTV hosts use plain `http://`.
- The app ships with no content of its own. Users bring their own server details.
- Not included yet: full TV guide grid, M3U playlist login, Android TV remote layout.
