package com.szplus.player

import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.DateFormat
import java.util.Date

@Composable
fun AccountScreen(api: XtreamApi, vm: AppViewModel) {
    val ctx = LocalContext.current
    val dataSaver by vm.dataSaver.collectAsStateWithLifecycle()
    var info by remember { mutableStateOf<UserInfo?>(null) }
    var confirmSignOut by remember { mutableStateOf(false) }
    val tap = rememberTap()

    LaunchedEffect(api) { info = runCatching { api.accountInfo() }.getOrNull() }

    val version = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "1.0"
    }

    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        0.85f, 1.15f,
        infiniteRepeatable(tween(3000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse-v",
    )

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Spacer(Modifier.height(10.dp))
        Text(stringResource(R.string.tab_account), color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)

        // Profile
        Column(
            Modifier.fillMaxWidth().glass(cornerRadius = 32.dp).padding(vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Box(Modifier.size(130.dp), contentAlignment = Alignment.Center) {
                Box(
                    Modifier
                        .size(130.dp)
                        .graphicsLayer { scaleX = pulse; scaleY = pulse }
                        .background(
                            Brush.radialGradient(listOf(AppConfig.Accent.copy(alpha = 0.5f), Color.Transparent)),
                            CircleShape,
                        )
                )
                Image(painterResource(R.drawable.app_logo), null, Modifier.size(88.dp))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    AppConfig.APP_NAME,
                    style = TextStyle(brush = AppConfig.Gradient, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold),
                )
                Text(AppConfig.APP_NAME_AR, color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(stringResource(R.string.signed_in_as), color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                Text(api.creds.username, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        // Subscription
        info?.let { i ->
            Column(
                Modifier.fillMaxWidth().glass(cornerRadius = 26.dp).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                val status = i.status.orEmpty()
                InfoRow(
                    stringResource(R.string.status),
                    if (status.isEmpty() || status.lowercase() == "active") stringResource(R.string.active) else status,
                )
                Divider()
                val ts = i.expDate?.toDoubleOrNull()
                InfoRow(
                    stringResource(R.string.expires),
                    if (ts != null && ts > 0) DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date((ts * 1000).toLong()))
                    else stringResource(R.string.unlimited),
                )
                val maxCons = i.maxConnections
                if (!maxCons.isNullOrEmpty()) {
                    Divider()
                    InfoRow(stringResource(R.string.connections), "${i.activeCons ?: "0"} / $maxCons")
                }
            }
        }

        // Settings
        Column(
            Modifier.fillMaxWidth().glass(cornerRadius = 26.dp).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(stringResource(R.string.language), color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp)

            val tags = AppCompatDelegate.getApplicationLocales().toLanguageTags()
            val current = when {
                tags.startsWith("ar") -> "ar"
                tags.startsWith("en") -> "en"
                else -> "system"
            }
            Segmented(
                options = listOf(
                    "system" to stringResource(R.string.lang_system),
                    "en" to "English",
                    "ar" to "العربية",
                ),
                selected = current,
                onSelect = { code ->
                    if (code != current) {
                        tap()
                        AppCompatDelegate.setApplicationLocales(
                            if (code == "system") LocaleListCompat.getEmptyLocaleList()
                            else LocaleListCompat.forLanguageTags(code)
                        )
                    }
                },
            )

            Row(
                Modifier.fillMaxWidth().padding(top = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    stringResource(R.string.data_saver), color = Color.White, fontSize = 16.sp,
                    modifier = Modifier.weight(1f),
                )
                Switch(
                    checked = dataSaver,
                    onCheckedChange = { tap(); vm.setDataSaver(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = AppConfig.OnAccent,
                        checkedTrackColor = AppConfig.Accent,
                        uncheckedThumbColor = Color.White.copy(alpha = 0.8f),
                        uncheckedTrackColor = Color.White.copy(alpha = 0.12f),
                        uncheckedBorderColor = Color.White.copy(alpha = 0.2f),
                    ),
                )
            }
            Text(stringResource(R.string.data_saver_hint), color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp)
        }

        // Sign out
        Row(
            Modifier
                .fillMaxWidth()
                .height(54.dp)
                .pressable { tap(); confirmSignOut = true }
                .glass(cornerRadius = 20.dp, tint = Color.Red.copy(alpha = 0.35f)),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.AutoMirrored.Filled.Logout, null, tint = AppConfig.Danger, modifier = Modifier.size(22.dp))
            Spacer(Modifier.size(10.dp))
            Text(stringResource(R.string.sign_out), color = AppConfig.Danger, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        }

        Text(
            stringResource(R.string.version_n, version),
            color = Color.White.copy(alpha = 0.35f), fontSize = 12.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 6.dp),
        )
        Spacer(Modifier.height(LocalBottomInset.current))
    }

    if (confirmSignOut) {
        AlertDialog(
            onDismissRequest = { confirmSignOut = false },
            containerColor = AppConfig.Card,
            title = { Text(stringResource(R.string.sign_out_of, AppConfig.APP_NAME), color = Color.White) },
            confirmButton = {
                TextButton(onClick = { confirmSignOut = false; vm.logout() }) {
                    Text(stringResource(R.string.sign_out), color = AppConfig.Danger, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmSignOut = false }) {
                    Text(stringResource(R.string.cancel), color = AppConfig.Accent)
                }
            },
        )
    }
}

@Composable
private fun Divider() {
    Box(Modifier.fillMaxWidth().height(0.7.dp).background(Color.White.copy(alpha = 0.08f)))
}

@Composable
private fun InfoRow(title: String, value: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun Segmented(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.06f))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        options.forEach { (code, label) ->
            val active = code == selected
            Box(
                Modifier
                    .weight(1f)
                    .height(38.dp)
                    .pressable(0.96f) { onSelect(code) }
                    .clip(CircleShape)
                    .then(if (active) Modifier.background(AppConfig.Gradient) else Modifier),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label,
                    color = if (active) AppConfig.OnAccent else Color.White.copy(alpha = 0.75f),
                    fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                )
            }
        }
    }
}
