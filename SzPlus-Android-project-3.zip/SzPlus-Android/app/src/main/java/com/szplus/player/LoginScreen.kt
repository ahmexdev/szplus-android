package com.szplus.player

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun LoginScreen(vm: AppViewModel) {
    val saved = remember { vm.savedCredentials }
    var server by rememberSaveable { mutableStateOf(saved?.server ?: AppConfig.DEFAULT_SERVER_URL) }
    var username by rememberSaveable { mutableStateOf(saved?.username ?: "") }
    var password by rememberSaveable { mutableStateOf(saved?.password ?: "") }
    var showPassword by remember { mutableStateOf(false) }

    val loading by vm.isLoggingIn.collectAsStateWithLifecycle()
    val error by vm.loginError.collectAsStateWithLifecycle()
    val tick by vm.errorTick.collectAsStateWithLifecycle()
    val focus = LocalFocusManager.current
    val tap = rememberTap()
    val heavy = rememberHeavyTap()
    val density = LocalDensity.current

    // Staggered entrance
    var appeared by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { appeared = true }
    val a1 by animateFloatAsState(if (appeared) 1f else 0f, tween(800, easing = FastOutSlowInEasing), label = "a1")
    val a2 by animateFloatAsState(if (appeared) 1f else 0f, tween(800, 120, FastOutSlowInEasing), label = "a2")
    val a3 by animateFloatAsState(if (appeared) 1f else 0f, tween(800, 220, FastOutSlowInEasing), label = "a3")

    // Floating logo
    val transition = rememberInfiniteTransition(label = "login")
    val float by transition.animateFloat(
        initialValue = -1f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "float",
    )

    // Wrong-password shake
    val shake = remember { Animatable(0f) }
    LaunchedEffect(tick) {
        if (tick > 0) {
            heavy()
            repeat(3) {
                shake.animateTo(10f, tween(55))
                shake.animateTo(-10f, tween(55))
            }
            shake.animateTo(0f, tween(55))
        }
    }

    val canSubmit = server.isNotBlank() && username.isNotBlank() && password.isNotEmpty()
    fun submit() {
        if (!canSubmit || loading) return
        focus.clearFocus()
        tap()
        vm.login(server.trim(), username.trim(), password)
    }

    Box(Modifier.fillMaxSize()) {
        AuroraBackground()
        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Spacer(Modifier.height(30.dp))

            // Header
            Column(
                Modifier.widthIn(max = 480.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(
                    Modifier
                        .size(190.dp)
                        .graphicsLayer {
                            val s = 0.4f + 0.6f * a1
                            scaleX = s; scaleY = s; alpha = a1
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Box(
                        Modifier
                            .size(190.dp)
                            .graphicsLayer {
                                val g = 1f + 0.15f * float
                                scaleX = g; scaleY = g
                            }
                            .background(
                                Brush.radialGradient(
                                    listOf(AppConfig.Accent.copy(alpha = 0.55f), Color.Transparent)
                                ),
                                RoundedCornerShape(100.dp),
                            )
                    )
                    Image(
                        painter = painterResource(R.drawable.app_logo),
                        contentDescription = null,
                        modifier = Modifier
                            .size(118.dp)
                            .graphicsLayer {
                                translationY = float * 7.dp.toPx()
                                rotationY = float * 7f
                                cameraDistance = 14f * density.density
                            },
                    )
                }
                Spacer(Modifier.height(10.dp))
                Column(
                    Modifier.graphicsLayer {
                        alpha = a2
                        translationY = (1f - a2) * 16.dp.toPx()
                    },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text(
                        AppConfig.APP_NAME,
                        style = TextStyle(brush = AppConfig.Gradient, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold),
                    )
                    Text(
                        AppConfig.APP_NAME_AR,
                        color = Color.White.copy(alpha = 0.85f), fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        stringResource(R.string.tagline),
                        color = Color.White.copy(alpha = 0.55f), fontSize = 13.sp,
                        modifier = Modifier.padding(top = 2.dp),
                    )
                }
            }

            Spacer(Modifier.height(30.dp))

            // Form
            Column(
                Modifier
                    .widthIn(max = 480.dp)
                    .fillMaxWidth()
                    .graphicsLayer {
                        alpha = a3
                        translationY = (1f - a3) * 50.dp.toPx()
                        translationX = shake.value.dp.toPx()
                    }
                    .glass(cornerRadius = 32.dp)
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                GlassField(
                    icon = Icons.Filled.Language,
                    value = server,
                    onChange = { server = it },
                    placeholder = stringResource(R.string.server_url),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.None,
                        autoCorrectEnabled = false,
                        keyboardType = KeyboardType.Uri,
                        imeAction = ImeAction.Next,
                    ),
                    keyboardActions = KeyboardActions(onNext = { focus.moveFocus(FocusDirection.Down) }),
                )
                GlassField(
                    icon = Icons.Filled.Person,
                    value = username,
                    onChange = { username = it },
                    placeholder = stringResource(R.string.username),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.None,
                        autoCorrectEnabled = false,
                        keyboardType = KeyboardType.Ascii,
                        imeAction = ImeAction.Next,
                    ),
                    keyboardActions = KeyboardActions(onNext = { focus.moveFocus(FocusDirection.Down) }),
                )
                GlassField(
                    icon = Icons.Filled.Lock,
                    value = password,
                    onChange = { password = it },
                    placeholder = stringResource(R.string.password),
                    visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.None,
                        autoCorrectEnabled = false,
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Go,
                    ),
                    keyboardActions = KeyboardActions(onGo = { submit() }),
                    trailing = {
                        Icon(
                            if (showPassword) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.55f),
                            modifier = Modifier
                                .size(36.dp)
                                .pressable(0.85f) { showPassword = !showPassword }
                                .padding(7.dp),
                        )
                    },
                )

                AnimatedVisibility(
                    visible = error != null,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically(),
                ) {
                    val e = error
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Filled.ErrorOutline, null, tint = AppConfig.Danger, modifier = Modifier.size(20.dp))
                        Text(
                            if (e != null) errorText(e) else "",
                            color = AppConfig.Danger, fontSize = 13.sp, textAlign = TextAlign.Start,
                        )
                    }
                }

                SignInButton(enabled = canSubmit, loading = loading, onClick = ::submit)
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun SignInButton(enabled: Boolean, loading: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    val alpha by animateFloatAsState(if (enabled) 1f else 0.45f, tween(250), label = "btn-alpha")
    val transition = rememberInfiniteTransition(label = "shine")
    val p by transition.animateFloat(
        0f, 1f, infiniteRepeatable(tween(3200, easing = LinearEasing), RepeatMode.Restart), label = "shine-p",
    )
    Box(
        Modifier
            .padding(top = 4.dp)
            .fillMaxWidth()
            .height(56.dp)
            .graphicsLayer { this.alpha = alpha }
            .then(
                if (enabled) Modifier.shadow(
                    16.dp, shape, ambientColor = AppConfig.Accent, spotColor = AppConfig.Accent,
                ) else Modifier
            )
            .pressable(0.96f, enabled = enabled && !loading, onClick = onClick)
            .clip(shape)
            .background(AppConfig.Gradient)
            .drawWithContent {
                drawContent()
                if (enabled) {
                    val w = size.width
                    val x = -w * 0.4f + p * w * 1.8f
                    drawRect(
                        Brush.linearGradient(
                            listOf(Color.Transparent, Color.White.copy(alpha = 0.38f), Color.Transparent),
                            start = Offset(x, 0f),
                            end = Offset(x + w * 0.35f, size.height * 0.3f),
                        )
                    )
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        if (loading) {
            CircularProgressIndicator(color = AppConfig.OnAccent, strokeWidth = 2.5.dp, modifier = Modifier.size(24.dp))
        } else {
            Text(stringResource(R.string.sign_in), color = AppConfig.OnAccent, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun GlassField(
    icon: ImageVector,
    value: String,
    onChange: (String) -> Unit,
    placeholder: String,
    keyboardOptions: KeyboardOptions,
    keyboardActions: KeyboardActions,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    trailing: (@Composable () -> Unit)? = null,
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(16.dp)
    val glow by animateFloatAsState(if (focused) 1f else 0f, tween(200), label = "glow")
    Row(
        Modifier
            .fillMaxWidth()
            .height(54.dp)
            .then(
                if (focused) Modifier.shadow(12.dp, shape, ambientColor = AppConfig.Accent, spotColor = AppConfig.Accent)
                else Modifier
            )
            .clip(shape)
            .background(Color.White.copy(alpha = 0.06f + 0.04f * glow))
            .border(
                width = if (focused) 1.4.dp else 0.7.dp,
                color = if (focused) AppConfig.Accent.copy(alpha = 0.85f) else Color.White.copy(alpha = 0.10f),
                shape = shape,
            )
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            icon, null,
            tint = if (focused) AppConfig.Accent else Color.White.copy(alpha = 0.55f),
            modifier = Modifier.size(22.dp),
        )
        Spacer(Modifier.size(12.dp))
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            if (value.isEmpty()) {
                Text(placeholder, color = Color.White.copy(alpha = 0.38f), fontSize = 16.sp, maxLines = 1)
            }
            BasicTextField(
                value = value,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                cursorBrush = SolidColor(AppConfig.Accent),
                visualTransformation = visualTransformation,
                keyboardOptions = keyboardOptions,
                keyboardActions = keyboardActions,
                modifier = Modifier
                    .fillMaxWidth()
                    .onFocusChanged { focused = it.isFocused },
            )
        }
        if (trailing != null) trailing()
    }
}
