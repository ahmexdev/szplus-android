package com.szplus.player

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun LiveTvScreen(api: XtreamApi, vm: AppViewModel, onPlay: (PlayItem) -> Unit) {
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val st = remember { BrowseState<LiveStream>() }
    var selected by rememberSaveable { mutableStateOf<String?>(null) }
    var favoritesOnly by rememberSaveable { mutableStateOf(false) }
    var search by rememberSaveable { mutableStateOf("") }
    var query by rememberSaveable { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val tap = rememberTap()

    suspend fun load() = st.load(
        cachedItems = { api.cachedLiveStreams() },
        cachedCategories = { api.cachedLiveCategories() },
        fetchItems = { api.liveStreams() },
        fetchCategories = { api.liveCategories() },
    )

    LaunchedEffect(api) { if (st.items.isEmpty()) load() }
    // Wait until typing pauses before filtering thousands of channels.
    LaunchedEffect(search) {
        delay(250)
        query = search
    }

    val filtered = remember(st.items, selected, favoritesOnly, query, favorites) {
        st.items.filter { s ->
            (selected == null || s.categoryId == selected) &&
                (!favoritesOnly || favorites.contains(s.id)) &&
                (query.isEmpty() || s.name.contains(query, ignoreCase = true))
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Spacer(Modifier.height(10.dp))
        ScreenTitle(stringResource(R.string.tab_live))
        Spacer(Modifier.height(10.dp))
        GlassSearchField(search, { search = it }, stringResource(R.string.search_channels), Modifier.padding(horizontal = 16.dp))
        CategoryBar(
            categories = st.categories,
            selected = selected,
            onSelect = { selected = it; favoritesOnly = false },
            showFavorites = true,
            favoritesOnly = favoritesOnly,
            onFavorites = { favoritesOnly = true; selected = null },
        )
        LoadingState(st.loading, st.error, SkeletonStyle.Rows, retry = { scope.launch { load() } }) {
            RefreshBox(
                refreshing = st.refreshing,
                onRefresh = { scope.launch { st.refreshing = true; load(); st.refreshing = false } },
            ) {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = LocalBottomInset.current + 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(filtered, key = { it.id }) { s ->
                        val fav = favorites.contains(s.id)
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .softCard()
                                .padding(start = 10.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Row(
                                Modifier
                                    .weight(1f)
                                    .pressable(0.97f) {
                                        tap()
                                        onPlay(PlayItem(s.id.toString(), s.name, api.liveUrls(s), s.id))
                                    },
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(14.dp),
                            ) {
                                PosterImage(
                                    s.icon,
                                    Modifier.size(54.dp).clip(RoundedCornerShape(13.dp)),
                                    contentScale = ContentScale.Fit,
                                    maxPixel = 200,
                                    fallbackText = s.name,
                                )
                                Text(
                                    s.name,
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f),
                                )
                            }
                            Box(
                                Modifier.size(46.dp).pressable(0.8f) { tap(); vm.toggleFavorite(s.id) },
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    if (fav) Icons.Filled.Star else Icons.Filled.StarBorder,
                                    contentDescription = null,
                                    tint = if (fav) AppConfig.Accent else Color.White.copy(alpha = 0.4f),
                                    modifier = Modifier.size(26.dp),
                                )
                            }
                        }
                    }
                    if (filtered.isEmpty()) {
                        item(key = "__empty") {
                            Column(
                                Modifier.fillMaxWidth().padding(top = 60.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Icon(
                                    if (favoritesOnly) Icons.Filled.Star else Icons.Filled.Search,
                                    null,
                                    tint = AppConfig.Accent.copy(alpha = 0.7f),
                                    modifier = Modifier.size(40.dp),
                                )
                                Text(
                                    stringResource(if (favoritesOnly) R.string.no_favorites else R.string.no_channels),
                                    color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                                )
                                if (favoritesOnly) {
                                    Text(
                                        stringResource(R.string.favorites_hint),
                                        color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp, textAlign = TextAlign.Center,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
