package com.szplus.player

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// MARK: - Glass surface

/**
 * Frosted glass: a translucent light gradient, a bright specular rim and a soft lime edge.
 * Sits on top of the animated aurora background.
 */
fun Modifier.glass(
    cornerRadius: Dp = 24.dp,
    tint: Color? = null,
    shape: Shape = RoundedCornerShape(cornerRadius),
): Modifier = this
    .clip(shape)
    .background(
        Brush.verticalGradient(
            listOf(Color.White.copy(alpha = 0.17f), Color.White.copy(alpha = 0.06f))
        )
    )
    .then(if (tint != null) Modifier.background(tint.copy(alpha = tint.alpha * 0.55f)) else Modifier)
    .border(
        width = 0.8.dp,
        brush = Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = 0.50f),
                Color.White.copy(alpha = 0.08f),
                AppConfig.Accent.copy(alpha = 0.22f),
            )
        ),
        shape = shape,
    )

/** A quieter card for list rows. */
fun Modifier.softCard(cornerRadius: Dp = 18.dp): Modifier {
    val shape = RoundedCornerShape(cornerRadius)
    return this
        .clip(shape)
        .background(Color.White.copy(alpha = 0.06f))
        .border(0.6.dp, Color.White.copy(alpha = 0.10f), shape)
}

// MARK: - Press feedback

fun Modifier.pressable(
    scaleDown: Float = 0.96f,
    enabled: Boolean = true,
    onClick: () -> Unit,
): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) scaleDown else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium),
        label = "press",
    )
    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(interactionSource = source, indication = null, enabled = enabled, onClick = onClick)
}

// MARK: - Haptics

@Composable
fun rememberTap(): () -> Unit {
    val haptic: HapticFeedback = LocalHapticFeedback.current
    return { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
}

@Composable
fun rememberHeavyTap(): () -> Unit {
    val haptic: HapticFeedback = LocalHapticFeedback.current
    return { haptic.performHapticFeedback(HapticFeedbackType.LongPress) }
}

// MARK: - Aurora background (lime light drifting over near-black)

@Composable
fun AuroraBackground(intensity: Float = 1f, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "aurora")
    // One full loop every two minutes. Each blob uses a whole number of cycles, so the loop is seamless.
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(120_000, easing = LinearEasing), RepeatMode.Restart),
        label = "aurora-t",
    )
    Box(
        modifier
            .fillMaxSize()
            .background(AppConfig.Background)
            .drawBehind {
                val w = size.width
                val h = size.height
                val tau = (2 * PI).toFloat() * t

                fun blob(color: Color, diameter: Float, cx: Float, cy: Float) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(color, color.copy(alpha = 0f)),
                            center = Offset(cx, cy),
                            radius = diameter / 2,
                        ),
                        radius = diameter / 2,
                        center = Offset(cx, cy),
                    )
                }

                blob(
                    AppConfig.Accent.copy(alpha = 0.34f * intensity), w * 0.95f,
                    w / 2 + cos(tau * 6) * w * 0.30f - w * 0.15f,
                    h / 2 + sin(tau * 5) * h * 0.18f - h * 0.28f,
                )
                blob(
                    AppConfig.AccentDeep.copy(alpha = 0.55f * intensity), w * 1.1f,
                    w / 2 + sin(tau * 4) * w * 0.32f + w * 0.20f,
                    h / 2 + cos(tau * 6) * h * 0.20f + h * 0.30f,
                )
                blob(
                    AppConfig.AccentBright.copy(alpha = 0.14f * intensity), w * 0.6f,
                    w / 2 + cos(tau * 8 + 1.2f) * w * 0.35f,
                    h / 2 + sin(tau * 7 + 0.6f) * h * 0.25f,
                )
                // Darken toward the bottom so content stays readable.
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color.Transparent, AppConfig.Background.copy(alpha = 0.65f)),
                        startY = h * 0.5f,
                        endY = h,
                    )
                )
            }
    )
}

// MARK: - Shimmer (skeleton loading)

fun Modifier.shimmer(): Modifier = composed {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val x by transition.animateFloat(
        initialValue = -1f,
        targetValue = 2f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart),
        label = "shimmer-x",
    )
    this.drawBehind {
        val w = size.width
        val start = x * w
        drawRect(
            brush = Brush.linearGradient(
                colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.10f), Color.Transparent),
                start = Offset(start, 0f),
                end = Offset(start + w * 0.6f, size.height * 0.4f),
            )
        )
    }
}

@Composable
fun animatedAccent(active: Boolean): Color =
    animateColorAsState(if (active) AppConfig.Accent else Color.White.copy(alpha = 0.62f), tween(250), label = "accent").value
