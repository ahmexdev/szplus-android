package com.szplus.player

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.lifecycle.compose.collectAsStateWithLifecycle

private enum class Tab(val titleRes: Int, val icon: ImageVector) {
    Live(R.string.tab_live, Icons.Filled.Tv),
    Movies(R.string.tab_movies, Icons.Filled.Movie),
    Series(R.string.tab_series, Icons.Filled.VideoLibrary),
    Account(R.string.tab_account, Icons.Filled.AccountCircle),
}

@Composable
fun MainScreen(api: XtreamApi, vm: AppViewModel) {
    var tabIndex by rememberSaveable { mutableIntStateOf(0) }
    val tab = Tab.values()[tabIndex]
    // Screens are created the first time you open them, so the app only loads what you use.
    var visitedMask by rememberSaveable { mutableIntStateOf(1) }
    var playing by remember { mutableStateOf<PlayItem?>(null) }
    var lastPlaying by remember { mutableStateOf<PlayItem?>(null) }
    playing?.let { lastPlaying = it }
    val dataSaver by vm.dataSaver.collectAsStateWithLifecycle()

    val navInset = WindowInsets.navigationBars.let {
        with(LocalDensity.current) { it.getBottom(this).toDp() }
    }
    val bottomInset = 84.dp + navInset

    Box(Modifier.fillMaxSize()) {
        AuroraBackground(intensity = 0.8f)

        CompositionLocalProvider(LocalBottomInset provides bottomInset) {
            Tab.values().forEach { t ->
                key(t) {
                if ((visitedMask shr t.ordinal) and 1 == 1) {
                    val active = tab == t
                    val p by animateFloatAsState(
                        if (active) 1f else 0f,
                        spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow),
                        label = "tab-${t.name}",
                    )
                    val dir = if (t.ordinal < tab.ordinal) -1f else 1f
                    val shift = with(LocalDensity.current) { 40.dp.toPx() }
                    Box(
                        Modifier
                            .fillMaxSize()
                            .zIndex(if (active) 1f else 0f)
                            .graphicsLayer {
                                alpha = p
                                val s = 0.94f + 0.06f * p
                                scaleX = s; scaleY = s
                                translationX = (1f - p) * dir * shift
                            }
                            .then(
                                if (active) Modifier
                                else Modifier.pointerInput(Unit) {
                                    // Hidden screens must not catch touches.
                                    awaitPointerEventScope {
                                        while (true) {
                                            awaitPointerEvent(PointerEventPass.Initial).changes.forEach { it.consume() }
                                        }
                                    }
                                }
                            )
                    ) {
                        when (t) {
                            Tab.Live -> LiveTvScreen(api, vm) { playing = it }
                            Tab.Movies -> MoviesScreen(api) { playing = it }
                            Tab.Series -> SeriesScreen(api) { playing = it }
                            Tab.Account -> AccountScreen(api, vm)
                        }
                    }
                }
                }
            }
        }

        GlassTabBar(
            selected = tab,
            onSelect = { t ->
                tabIndex = t.ordinal
                visitedMask = visitedMask or (1 shl t.ordinal)
            },
            modifier = Modifier.align(Alignment.BottomCenter).zIndex(2f),
        )

        AnimatedVisibility(
            visible = playing != null,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
            modifier = Modifier.zIndex(3f),
        ) {
            lastPlaying?.let { item ->
                PlayerScreen(api = api, item = item, dataSaver = dataSaver, onClose = { playing = null })
            }
        }
    }
}

// MARK: - Floating glass tab bar

@Composable
private fun GlassTabBar(selected: Tab, onSelect: (Tab) -> Unit, modifier: Modifier = Modifier) {
    val tap = rememberTap()
    val tabs = Tab.values()
    val pad = 6.dp
    BoxWithConstraints(
        modifier
            .navigationBarsPadding()
            .padding(horizontal = 22.dp)
            .padding(bottom = 6.dp)
            .fillMaxWidth()
    ) {
        val itemW = (maxWidth - pad * 2) / tabs.size
        val lensX by animateDpAsState(
            itemW * selected.ordinal,
            spring(dampingRatio = 0.76f, stiffness = Spring.StiffnessMediumLow),
            label = "lens",
        )
        Box(Modifier.fillMaxWidth().glass(cornerRadius = 36.dp).padding(pad)) {
            // Sliding highlight
            Box(
                Modifier
                    .offset(x = lensX)
                    .width(itemW)
                    .height(58.dp)
                    .shadow(10.dp, CircleShape, ambientColor = AppConfig.Accent, spotColor = AppConfig.Accent)
                    .clip(CircleShape)
                    .background(
                        Brush.verticalGradient(
                            listOf(AppConfig.Accent.copy(alpha = 0.30f), AppConfig.Accent.copy(alpha = 0.12f))
                        )
                    )
                    .border(0.8.dp, Color.White.copy(alpha = 0.28f), CircleShape)
            )
            Row(Modifier.fillMaxWidth()) {
                tabs.forEach { t ->
                    val active = t == selected
                    val bounce by animateFloatAsState(
                        if (active) 1.1f else 1f,
                        spring(dampingRatio = 0.4f, stiffness = Spring.StiffnessMedium),
                        label = "bounce",
                    )
                    val tint = animatedAccent(active)
                    Column(
                        Modifier
                            .weight(1f)
                            .height(58.dp)
                            .pressable(0.92f) {
                                if (!active) {
                                    tap()
                                    onSelect(t)
                                }
                            },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        Icon(
                            t.icon, null, tint = tint,
                            modifier = Modifier.size(24.dp).graphicsLayer { scaleX = bounce; scaleY = bounce },
                        )
                        Text(
                            stringResource(t.titleRes), color = tint, fontSize = 10.5.sp,
                            fontWeight = FontWeight.SemiBold, maxLines = 1,
                            modifier = Modifier.padding(top = 3.dp),
                        )
                    }
                }
            }
        }
    }
}
