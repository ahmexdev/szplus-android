package com.szplus.player

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** Edit this file to brand the app. Colors match the Sz plus store (lime #82e705 on near-black). */
object AppConfig {
    const val APP_NAME = "Sz plus"
    const val APP_NAME_AR = "سز بلس"

    /** Optional: pre-fill the server URL on the login screen. Example: "http://your-host.com:8080" */
    const val DEFAULT_SERVER_URL = ""

    val Accent = Color(0xFF82E705)
    val AccentBright = Color(0xFFC6FF4D)
    val AccentDeep = Color(0xFF2E6B00)
    val Background = Color(red = 0.040f, green = 0.050f, blue = 0.035f)
    val Card = Color(red = 0.075f, green = 0.090f, blue = 0.065f)
    /** Text and icons placed on top of the lime accent. */
    val OnAccent = Color(red = 0.03f, green = 0.06f, blue = 0.01f)
    val Danger = Color(0xFFFF6B6B)

    val Gradient: Brush
        get() = Brush.linearGradient(listOf(AccentBright, Accent))
}
