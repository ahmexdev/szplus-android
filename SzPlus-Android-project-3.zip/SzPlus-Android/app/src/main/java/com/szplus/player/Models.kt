package com.szplus.player

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject

// Xtream servers return mixed string/number types, so everything is read leniently.

fun JSONObject.str(key: String): String? {
    if (!has(key) || isNull(key)) return null
    return when (val v = get(key)) {
        is String -> v
        is Boolean -> if (v) "1" else "0"
        is Number -> {
            val d = v.toDouble()
            if (d % 1.0 == 0.0 && Math.abs(d) < 9.0e15) d.toLong().toString() else v.toString()
        }
        else -> null
    }
}

fun JSONObject.int(key: String): Int = str(key)?.toDoubleOrNull()?.toInt() ?: 0

data class Credentials(val server: String, val username: String, val password: String)

data class UserInfo(
    val username: String?,
    val status: String?,
    val expDate: String?,
    val maxConnections: String?,
    val activeCons: String?,
)

data class Category(val id: String, val name: String)

data class LiveStream(val id: Int, val name: String, val icon: String?, val categoryId: String?)

data class Movie(
    val id: Int,
    val name: String,
    val icon: String?,
    val categoryId: String?,
    val ext: String,
    val rating: String?,
)

data class Series(
    val id: Int,
    val name: String,
    val cover: String?,
    val categoryId: String?,
    val plot: String?,
)

data class Episode(val id: String, val title: String, val ext: String, val episodeNum: Int, val season: Int)

data class EpgEntry(val id: String, val title: String, val startMs: Long, val endMs: Long)

/** Something the player can open. Several URLs are tried in order until one works. */
data class PlayItem(
    val id: String,
    val title: String,
    val urls: List<String>,
    val epgStreamId: Int? = null,
)

// MARK: - Parsers

private inline fun <T> JSONArray.mapObjects(block: (JSONObject) -> T): List<T> {
    val out = ArrayList<T>(length())
    for (i in 0 until length()) {
        val o = optJSONObject(i) ?: continue
        out.add(block(o))
    }
    return out
}

fun parseCategories(text: String): List<Category> =
    JSONArray(text).mapObjects { Category(it.str("category_id") ?: "", it.str("category_name") ?: "Unknown") }

fun parseLive(text: String): List<LiveStream> =
    JSONArray(text).mapObjects {
        LiveStream(it.int("stream_id"), it.str("name") ?: "", it.str("stream_icon"), it.str("category_id"))
    }

fun parseMovies(text: String): List<Movie> =
    JSONArray(text).mapObjects {
        Movie(
            id = it.int("stream_id"),
            name = it.str("name") ?: "",
            icon = it.str("stream_icon"),
            categoryId = it.str("category_id"),
            ext = it.str("container_extension").takeUnless { e -> e.isNullOrBlank() } ?: "mp4",
            rating = it.str("rating"),
        )
    }

fun parseSeries(text: String): List<Series> =
    JSONArray(text).mapObjects {
        Series(it.int("series_id"), it.str("name") ?: "", it.str("cover"), it.str("category_id"), it.str("plot"))
    }

private fun parseEpisode(o: JSONObject, fallbackSeason: Int): Episode =
    Episode(
        id = o.str("id") ?: "",
        title = o.str("title") ?: "Episode",
        ext = o.str("container_extension").takeUnless { it.isNullOrBlank() } ?: "mp4",
        episodeNum = o.int("episode_num"),
        season = o.str("season")?.toDoubleOrNull()?.toInt() ?: fallbackSeason,
    )

/** Season number -> episodes. Servers send either an object keyed by season or an array of arrays. */
fun parseSeriesInfo(text: String): Map<String, List<Episode>> {
    val root = JSONObject(text)
    val out = LinkedHashMap<String, List<Episode>>()
    when (val eps = root.opt("episodes")) {
        is JSONObject -> {
            val keys = eps.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val arr = eps.optJSONArray(k) ?: continue
                out[k] = arr.mapObjects { parseEpisode(it, k.toIntOrNull() ?: 1) }
            }
        }
        is JSONArray -> {
            for (i in 0 until eps.length()) {
                val arr = eps.optJSONArray(i) ?: continue
                out[(i + 1).toString()] = arr.mapObjects { parseEpisode(it, i + 1) }
            }
        }
    }
    return out
}

fun parseUserInfo(text: String): UserInfo? {
    val info = JSONObject(text).optJSONObject("user_info") ?: return null
    return UserInfo(
        username = info.str("username"),
        status = info.str("status"),
        expDate = info.str("exp_date"),
        maxConnections = info.str("max_connections"),
        activeCons = info.str("active_cons"),
    )
}

private fun decodeTitle(raw: String): String {
    // Servers send program titles base64-encoded.
    return try {
        val bytes = Base64.decode(raw, Base64.DEFAULT)
        val s = String(bytes, Charsets.UTF_8)
        if (s.isNotEmpty() && !s.contains('\uFFFD')) s else raw
    } catch (e: Exception) {
        raw
    }
}

fun parseEpg(text: String): List<EpgEntry> {
    val arr = JSONObject(text).optJSONArray("epg_listings") ?: return emptyList()
    return arr.mapObjects {
        EpgEntry(
            id = it.str("id") ?: "",
            title = decodeTitle(it.str("title") ?: ""),
            startMs = ((it.str("start_timestamp")?.toDoubleOrNull() ?: 0.0) * 1000).toLong(),
            endMs = ((it.str("stop_timestamp")?.toDoubleOrNull() ?: 0.0) * 1000).toLong(),
        )
    }
}
