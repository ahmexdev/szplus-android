package com.szplus.player

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SeriesScreen(api: XtreamApi, onPlay: (PlayItem) -> Unit) {
    val st = remember { BrowseState<Series>() }
    var selected by rememberSaveable { mutableStateOf<String?>(null) }
    var search by rememberSaveable { mutableStateOf("") }
    var query by rememberSaveable { mutableStateOf("") }
    var open by remember { mutableStateOf<Series?>(null) }
    var lastOpen by remember { mutableStateOf<Series?>(null) }
    val scope = rememberCoroutineScope()
    val tap = rememberTap()

    suspend fun load() = st.load(
        cachedItems = { api.cachedSeries() },
        cachedCategories = { api.cachedSeriesCategories() },
        fetchItems = { api.series() },
        fetchCategories = { api.seriesCategories() },
    )

    LaunchedEffect(api) { if (st.items.isEmpty()) load() }
    LaunchedEffect(search) {
        delay(250)
        query = search
    }
    open?.let { lastOpen = it }

    val filtered = remember(st.items, selected, query) {
        st.items.filter { s ->
            (selected == null || s.categoryId == selected) &&
                (query.isEmpty() || s.name.contains(query, ignoreCase = true))
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Spacer(Modifier.height(10.dp))
            ScreenTitle(stringResource(R.string.tab_series))
            Spacer(Modifier.height(10.dp))
            GlassSearchField(search, { search = it }, stringResource(R.string.search_series), Modifier.padding(horizontal = 16.dp))
            CategoryBar(st.categories, selected, onSelect = { selected = it })
            LoadingState(st.loading, st.error, SkeletonStyle.Grid, retry = { scope.launch { load() } }) {
                RefreshBox(
                    refreshing = st.refreshing,
                    onRefresh = { scope.launch { st.refreshing = true; load(); st.refreshing = false } },
                ) {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(104.dp),
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = LocalBottomInset.current + 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        items(filtered, key = { it.id }) { s ->
                            PosterCard(
                                title = s.name,
                                imageUrl = s.cover,
                                modifier = Modifier.pressable(0.94f) { tap(); open = s },
                            )
                        }
                    }
                }
            }
        }

        // Series page grows out of the grid with a zoom.
        AnimatedVisibility(
            visible = open != null,
            enter = fadeIn(tween(260)) + scaleIn(tween(320), initialScale = 0.88f),
            exit = fadeOut(tween(200)) + scaleOut(tween(240), targetScale = 0.92f),
        ) {
            lastOpen?.let { s ->
                SeriesDetail(api, s, onBack = { open = null }, onPlay = onPlay)
            }
        }
    }
}

@Composable
private fun SeriesDetail(api: XtreamApi, series: Series, onBack: () -> Unit, onPlay: (PlayItem) -> Unit) {
    var seasons by remember(series.id) { mutableStateOf<Map<String, List<Episode>>>(emptyMap()) }
    var selectedSeason by remember(series.id) { mutableStateOf<String?>(null) }
    var loading by remember(series.id) { mutableStateOf(true) }
    var error by remember(series.id) { mutableStateOf<ApiError?>(null) }
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val tap = rememberTap()

    BackHandler(onBack = onBack)

    suspend fun load() {
        loading = true
        error = null
        try {
            seasons = api.seriesInfo(series.id)
            selectedSeason = seasons.keys.sortedBy { it.toIntOrNull() ?: 0 }.firstOrNull()
        } catch (e: kotlin.coroutines.cancellation.CancellationException) {
            throw e
        } catch (e: ApiError) {
            error = e
        } catch (e: Exception) {
            error = ApiError.Unreachable
        }
        loading = false
    }
    LaunchedEffect(series.id) { load() }

    val sortedSeasons = remember(seasons) { seasons.keys.sortedBy { it.toIntOrNull() ?: 0 } }
    val chips = remember(sortedSeasons) { sortedSeasons.map { Category(it, it) } }
    val episodes = remember(seasons, selectedSeason) {
        (seasons[selectedSeason] ?: emptyList()).sortedBy { it.episodeNum }
    }

    Box(Modifier.fillMaxSize().background(AppConfig.Background)) {
        // Blurred poster glow behind everything.
        Box(Modifier.fillMaxWidth().height(440.dp)) {
            PosterImage(
                series.cover,
                Modifier.fillMaxSize().blur(55.dp).alpha(0.5f),
                fallbackText = series.name,
            )
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color.Transparent, AppConfig.Background))
                )
            )
        }

        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Box(
                Modifier
                    .padding(start = 14.dp, top = 8.dp)
                    .size(44.dp)
                    .glass(cornerRadius = 22.dp)
                    .pressable { onBack() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
            }
            LoadingState(loading, error, SkeletonStyle.Rows, retry = { scope.launch { load() } }) {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = LocalBottomInset.current + 12.dp, top = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    item(key = "header") {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                        ) {
                            val shape = RoundedCornerShape(18.dp)
                            PosterImage(
                                series.cover,
                                Modifier
                                    .width(116.dp)
                                    .height(174.dp)
                                    .clip(shape)
                                    .border(0.8.dp, Color.White.copy(alpha = 0.18f), shape),
                                fallbackText = series.name,
                            )
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(series.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                val plot = series.plot
                                if (!plot.isNullOrBlank()) {
                                    Text(
                                        plot, color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp,
                                        maxLines = 7, overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                        }
                    }
                    item(key = "seasons") {
                        CategoryBar(
                            categories = chips,
                            selected = selectedSeason,
                            onSelect = { selectedSeason = it },
                            showAll = false,
                            titleFor = { ctx.getString(R.string.season_n, it.id) },
                        )
                    }
                    items(episodes, key = { it.id + "-" + it.season }) { ep ->
                        Row(
                            Modifier
                                .padding(horizontal = 16.dp)
                                .fillMaxWidth()
                                .pressable(0.97f) {
                                    tap()
                                    onPlay(PlayItem(ep.id, ep.title, listOf(api.episodeUrl(ep))))
                                }
                                .softCard()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            Box(
                                Modifier.size(34.dp).clip(CircleShape).background(AppConfig.Gradient),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(
                                    ep.episodeNum.toString(), color = AppConfig.OnAccent,
                                    fontWeight = FontWeight.Bold, fontSize = 14.sp,
                                )
                            }
                            Text(
                                ep.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                                maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
                            )
                            Icon(Icons.Filled.PlayArrow, null, tint = AppConfig.Accent, modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }
        }
    }
}
