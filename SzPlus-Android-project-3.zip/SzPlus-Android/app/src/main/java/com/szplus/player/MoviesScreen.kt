package com.szplus.player

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun MoviesScreen(api: XtreamApi, onPlay: (PlayItem) -> Unit) {
    val st = remember { BrowseState<Movie>() }
    var selected by rememberSaveable { mutableStateOf<String?>(null) }
    var search by rememberSaveable { mutableStateOf("") }
    var query by rememberSaveable { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val tap = rememberTap()

    suspend fun load() = st.load(
        cachedItems = { api.cachedMovies() },
        cachedCategories = { api.cachedMovieCategories() },
        fetchItems = { api.movies() },
        fetchCategories = { api.movieCategories() },
    )

    LaunchedEffect(api) { if (st.items.isEmpty()) load() }
    LaunchedEffect(search) {
        delay(250)
        query = search
    }

    val filtered = remember(st.items, selected, query) {
        st.items.filter { m ->
            (selected == null || m.categoryId == selected) &&
                (query.isEmpty() || m.name.contains(query, ignoreCase = true))
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Spacer(Modifier.height(10.dp))
        ScreenTitle(stringResource(R.string.tab_movies))
        Spacer(Modifier.height(10.dp))
        GlassSearchField(search, { search = it }, stringResource(R.string.search_movies), Modifier.padding(horizontal = 16.dp))
        CategoryBar(st.categories, selected, onSelect = { selected = it })
        LoadingState(st.loading, st.error, SkeletonStyle.Grid, retry = { scope.launch { load() } }) {
            RefreshBox(
                refreshing = st.refreshing,
                onRefresh = { scope.launch { st.refreshing = true; load(); st.refreshing = false } },
            ) {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(104.dp),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = LocalBottomInset.current + 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    items(filtered, key = { it.id }) { m ->
                        PosterCard(
                            title = m.name,
                            imageUrl = m.icon,
                            badge = m.rating,
                            modifier = Modifier.pressable(0.94f) {
                                tap()
                                onPlay(PlayItem(m.id.toString(), m.name, listOf(api.movieUrl(m))))
                            },
                        )
                    }
                }
            }
        }
    }
}
