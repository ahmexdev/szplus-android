package com.szplus.player

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import coil.size.Size

// MARK: - Images (downloaded once, shrunk and cached by Coil)

@Composable
fun PosterImage(
    url: String?,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
    maxPixel: Int = 400,
    fallbackText: String = "",
) {
    val ctx = LocalContext.current
    Box(modifier.background(Color.White.copy(alpha = 0.05f))) {
        if (url.isNullOrBlank()) {
            Initial(fallbackText)
        } else {
            SubcomposeAsyncImage(
                model = ImageRequest.Builder(ctx)
                    .data(url)
                    .size(Size(maxPixel, maxPixel))
                    .crossfade(250)
                    .memoryCachePolicy(CachePolicy.ENABLED)
                    .diskCachePolicy(CachePolicy.ENABLED)
                    .build(),
                contentDescription = null,
                contentScale = contentScale,
                modifier = Modifier.fillMaxSize(),
                loading = { Box(Modifier.fillMaxSize().shimmer()) },
                error = { Initial(fallbackText) },
            )
        }
    }
}

@Composable
private fun Initial(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            text.trim().take(1).uppercase(),
            color = AppConfig.Accent.copy(alpha = 0.55f),
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
        )
    }
}

@Composable
fun PosterCard(title: String, imageUrl: String?, badge: String? = null, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(18.dp)
    Box(
        modifier
            .fillMaxWidth()
            .aspectRatio(2f / 3f)
            .clip(shape)
            .border(0.8.dp, Color.White.copy(alpha = 0.14f), shape)
    ) {
        PosterImage(imageUrl, Modifier.fillMaxSize(), fallbackText = title)
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        0.55f to Color.Transparent,
                        1f to Color.Black.copy(alpha = 0.82f),
                    )
                )
        )
        Text(
            title,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(horizontal = 9.dp, vertical = 8.dp),
        )
        val r = badge?.toDoubleOrNull()
        if (r != null && r > 0) {
            Text(
                "★ " + (if (r % 1.0 == 0.0) r.toInt().toString() else "%.1f".format(r)),
                color = AppConfig.OnAccent,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(7.dp)
                    .clip(CircleShape)
                    .background(AppConfig.Gradient)
                    .padding(horizontal = 7.dp, vertical = 2.dp),
            )
        }
    }
}

// MARK: - Category / season chips

@Composable
fun CategoryBar(
    categories: List<Category>,
    selected: String?,
    onSelect: (String?) -> Unit,
    modifier: Modifier = Modifier,
    showAll: Boolean = true,
    showFavorites: Boolean = false,
    favoritesOnly: Boolean = false,
    onFavorites: () -> Unit = {},
    titleFor: ((Category) -> String)? = null,
) {
    val tap = rememberTap()
    LazyRow(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (showAll) {
            item(key = "__all") {
                Chip(stringResource(R.string.all), selected == null && !favoritesOnly) {
                    tap(); onSelect(null)
                }
            }
        }
        if (showFavorites) {
            item(key = "__fav") {
                Chip(stringResource(R.string.favorites), favoritesOnly) { tap(); onFavorites() }
            }
        }
        items(categories, key = { it.id }) { c ->
            Chip(titleFor?.invoke(c) ?: c.name, selected == c.id) { tap(); onSelect(c.id) }
        }
    }
}

@Composable
private fun Chip(title: String, active: Boolean, onClick: () -> Unit) {
    val fg = animateColorAsState(
        if (active) AppConfig.OnAccent else Color.White.copy(alpha = 0.78f), tween(220), label = "chip-fg"
    )
    val shape = CircleShape
    Box(
        Modifier
            .pressable(0.95f, onClick = onClick)
            .then(
                if (active) Modifier.shadow(10.dp, shape, ambientColor = AppConfig.Accent, spotColor = AppConfig.Accent)
                else Modifier
            )
            .clip(shape)
            .then(
                if (active) Modifier.background(AppConfig.Gradient)
                else Modifier
                    .background(Color.White.copy(alpha = 0.06f))
                    .border(0.6.dp, Color.White.copy(alpha = 0.10f), shape)
            )
            .padding(horizontal = 16.dp, vertical = 9.dp)
    ) {
        Text(title, color = fg.value, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

// MARK: - Search field

@Composable
fun GlassSearchField(value: String, onChange: (String) -> Unit, placeholder: String, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier
            .fillMaxWidth()
            .height(48.dp)
            .glass(cornerRadius = 16.dp)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Search, null, tint = Color.White.copy(alpha = 0.55f), modifier = Modifier.size(20.dp))
        Spacer(Modifier.size(10.dp))
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            if (value.isEmpty()) {
                Text(placeholder, color = Color.White.copy(alpha = 0.40f), fontSize = 15.sp)
            }
            BasicTextField(
                value = value,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                cursorBrush = SolidColor(AppConfig.Accent),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        if (value.isNotEmpty()) {
            Icon(
                Icons.Filled.Close, null,
                tint = Color.White.copy(alpha = 0.55f),
                modifier = Modifier
                    .size(32.dp)
                    .pressable { onChange("") }
                    .padding(6.dp),
            )
        }
    }
}

// MARK: - Screen header

@Composable
fun ScreenTitle(title: String, modifier: Modifier = Modifier) {
    Text(
        title,
        color = Color.White,
        fontSize = 32.sp,
        fontWeight = FontWeight.ExtraBold,
        modifier = modifier.padding(horizontal = 20.dp),
    )
}

// MARK: - Loading / error wrapper with skeletons

enum class SkeletonStyle { Rows, Grid }

@Composable
fun LoadingState(
    isLoading: Boolean,
    error: ApiError?,
    style: SkeletonStyle,
    retry: () -> Unit,
    content: @Composable () -> Unit,
) {
    when {
        isLoading -> Skeleton(style)
        error != null -> {
            val tap = rememberTap()
            Column(
                Modifier.fillMaxSize().padding(horizontal = 30.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Icon(Icons.Filled.WifiOff, null, tint = AppConfig.Accent, modifier = Modifier.size(42.dp))
                Spacer(Modifier.height(14.dp))
                Text(errorText(error), color = Color.White.copy(alpha = 0.7f), textAlign = TextAlign.Center)
                Spacer(Modifier.height(14.dp))
                Box(
                    Modifier
                        .pressable { tap(); retry() }
                        .clip(CircleShape)
                        .background(AppConfig.Gradient)
                        .padding(horizontal = 28.dp, vertical = 13.dp)
                ) {
                    Text(stringResource(R.string.try_again), color = AppConfig.OnAccent, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
        else -> content()
    }
}

@Composable
private fun Skeleton(style: SkeletonStyle) {
    when (style) {
        SkeletonStyle.Rows -> Column(
            Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            repeat(9) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(74.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color.White.copy(alpha = 0.06f))
                        .shimmer()
                )
            }
        }
        SkeletonStyle.Grid -> Column(
            Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            repeat(3) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    repeat(3) {
                        Box(
                            Modifier
                                .weight(1f)
                                .aspectRatio(2f / 3f)
                                .clip(RoundedCornerShape(18.dp))
                                .background(Color.White.copy(alpha = 0.06f))
                                .shimmer()
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun errorText(e: ApiError): String = stringResource(
    when (e) {
        ApiError.BadUrl -> R.string.err_bad_url
        ApiError.InvalidLogin -> R.string.err_invalid_login
        ApiError.Expired -> R.string.err_expired
        ApiError.Unexpected -> R.string.err_unexpected
        ApiError.Unreachable -> R.string.err_unreachable
    }
)
