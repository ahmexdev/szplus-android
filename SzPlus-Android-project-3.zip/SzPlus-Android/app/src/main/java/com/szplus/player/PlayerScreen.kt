package com.szplus.player

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

private fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(api: XtreamApi, item: PlayItem, dataSaver: Boolean, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val tap = rememberTap()
    var failed by remember(item.id) { mutableStateOf(false) }
    var showTitle by remember(item.id) { mutableStateOf(true) }
    var epg by remember(item.id) { mutableStateOf<List<EpgEntry>>(emptyList()) }
    var showEpg by remember(item.id) { mutableStateOf(false) }

    val exo = remember(item.id) {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(USER_AGENT)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)
        ExoPlayer.Builder(ctx)
            .setMediaSourceFactory(DefaultMediaSourceFactory(ctx).setDataSourceFactory(http))
            .build()
            .apply {
                playWhenReady = true
                if (dataSaver) {
                    trackSelectionParameters = trackSelectionParameters.buildUpon()
                        .setMaxVideoBitrate(1_500_000)
                        .build()
                }
            }
    }

    // Tries each URL in turn (for live channels: .m3u8 first, then .ts).
    DisposableEffect(exo) {
        var index = 0
        fun start(i: Int) {
            if (i >= item.urls.size) {
                failed = true
                return
            }
            index = i
            exo.setMediaItem(MediaItem.fromUri(item.urls[i]))
            exo.prepare()
            exo.play()
        }
        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    exo.seekToDefaultPosition()
                    exo.prepare()
                } else {
                    start(index + 1)
                }
            }
        }
        exo.addListener(listener)
        start(0)
        onDispose {
            exo.removeListener(listener)
            exo.release()
        }
    }

    // Immersive fullscreen while playing.
    DisposableEffect(Unit) {
        val window = ctx.findActivity()?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }

    fun close() {
        exo.pause()
        onClose()
    }
    BackHandler { close() }

    LaunchedEffect(item.id) {
        delay(3_500)
        showTitle = false
    }

    // TV guide for live channels: show it for a few seconds, then tuck it away.
    LaunchedEffect(item.id) {
        val id = item.epgStreamId ?: return@LaunchedEffect
        val list = runCatching { api.shortEpg(id) }.getOrNull().orEmpty()
        if (list.isEmpty()) return@LaunchedEffect
        epg = list.sortedBy { it.startMs }
        showEpg = true
        delay(8_000)
        showEpg = false
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                PlayerView(c).apply {
                    this.player = exo
                    useController = true
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
                    setShowNextButton(false)
                    setShowPreviousButton(false)
                    keepScreenOn = true
                    setBackgroundColor(android.graphics.Color.BLACK)
                }
            },
            onRelease = { it.player = null },
        )

        if (failed) {
            Column(
                Modifier
                    .align(Alignment.Center)
                    .padding(24.dp)
                    .glass(cornerRadius = 28.dp)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Icon(Icons.Filled.Warning, null, tint = AppConfig.Accent, modifier = Modifier.size(36.dp))
                Text(stringResource(R.string.cant_play), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    stringResource(R.string.cant_play_hint),
                    color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp, textAlign = TextAlign.Center,
                )
            }
        }

        AnimatedVisibility(
            visible = showEpg && epg.isNotEmpty(),
            enter = slideInVertically { -it } + fadeIn(),
            exit = slideOutVertically { -it } + fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter),
        ) {
            EpgCard(epg, Modifier.statusBarsPadding().padding(start = 16.dp, end = 16.dp, top = 76.dp))
        }

        Row(
            Modifier.statusBarsPadding().padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            GlassCircleButton(onClick = { close() }) {
                Icon(Icons.Filled.KeyboardArrowDown, stringResource(R.string.close), tint = Color.White)
            }
            if (epg.isNotEmpty()) {
                GlassCircleButton(onClick = { tap(); showEpg = !showEpg }) {
                    Icon(Icons.Filled.Tv, stringResource(R.string.tv_guide), tint = Color.White, modifier = Modifier.size(22.dp))
                }
            }
            AnimatedVisibility(
                visible = showTitle,
                enter = slideInHorizontally { -it / 2 } + fadeIn(),
                exit = slideOutHorizontally { -it / 2 } + fadeOut(tween(300)),
            ) {
                Box(
                    Modifier
                        .height(44.dp)
                        .glass(cornerRadius = 22.dp)
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        item.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}

@Composable
private fun GlassCircleButton(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .glass(cornerRadius = 22.dp)
            .pressable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}
