package com.szplus.player

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle

class MainActivity : AppCompatActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
        )
        super.onCreate(savedInstanceState)
        setContent {
            SzPlusTheme {
                Root(vm)
            }
        }
    }
}

@Composable
private fun SzPlusTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = AppConfig.Accent,
            onPrimary = AppConfig.OnAccent,
            background = AppConfig.Background,
            onBackground = androidx.compose.ui.graphics.Color.White,
            surface = AppConfig.Card,
            onSurface = androidx.compose.ui.graphics.Color.White,
        ),
        content = content,
    )
}

@Composable
private fun Root(vm: AppViewModel) {
    val api by vm.api.collectAsStateWithLifecycle()
    Box(Modifier.fillMaxSize().background(AppConfig.Background)) {
        AnimatedContent(
            targetState = api,
            transitionSpec = {
                if (targetState != null) {
                    (fadeIn(tween(600)) + scaleIn(tween(700), initialScale = 0.94f)) togetherWith fadeOut(tween(300))
                } else {
                    (fadeIn(tween(600)) + scaleIn(tween(700), initialScale = 1.06f)) togetherWith
                        (fadeOut(tween(300)) + scaleOut(tween(300), targetScale = 0.94f))
                }
            },
            label = "root",
        ) { current ->
            if (current != null) MainScreen(current, vm) else LoginScreen(vm)
        }
    }
}
