package com.szplus.player

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("szplus", Context.MODE_PRIVATE)

    private val _api = MutableStateFlow<XtreamApi?>(null)
    val api: StateFlow<XtreamApi?> = _api

    private val _isLoggingIn = MutableStateFlow(false)
    val isLoggingIn: StateFlow<Boolean> = _isLoggingIn

    private val _loginError = MutableStateFlow<ApiError?>(null)
    val loginError: StateFlow<ApiError?> = _loginError

    /** Bumps on every failed attempt so the login card can shake again. */
    private val _errorTick = MutableStateFlow(0)
    val errorTick: StateFlow<Int> = _errorTick

    private val _favorites = MutableStateFlow<Set<Int>>(emptySet())
    val favorites: StateFlow<Set<Int>> = _favorites

    private val _dataSaver = MutableStateFlow(prefs.getBoolean("dataSaver", false))
    val dataSaver: StateFlow<Boolean> = _dataSaver

    init {
        savedCredentials?.let { _api.value = XtreamApi(app, it) }
        _favorites.value = (prefs.getString("favorite_live_ids", "") ?: "")
            .split(",").mapNotNull { it.toIntOrNull() }.toSet()
    }

    val savedCredentials: Credentials?
        get() {
            val server = prefs.getString("server", null) ?: return null
            val user = prefs.getString("username", null) ?: return null
            val pass = prefs.getString("password", null) ?: return null
            return Credentials(server, user, pass)
        }

    fun login(server: String, username: String, password: String) {
        if (_isLoggingIn.value) return
        viewModelScope.launch {
            _loginError.value = null
            _isLoggingIn.value = true
            val creds = Credentials(server, username, password)
            val candidate = XtreamApi(getApplication(), creds)
            try {
                candidate.login()
                prefs.edit()
                    .putString("server", server)
                    .putString("username", username)
                    .putString("password", password)
                    .apply()
                _api.value = candidate
            } catch (e: ApiError) {
                _loginError.value = e
                _errorTick.value += 1
            } catch (e: Exception) {
                _loginError.value = ApiError.Unreachable
                _errorTick.value += 1
            } finally {
                _isLoggingIn.value = false
            }
        }
    }

    fun logout() {
        _api.value?.clearCache()
        prefs.edit().remove("server").remove("username").remove("password").apply()
        _api.value = null
        _loginError.value = null
    }

    fun toggleFavorite(id: Int) {
        val next = _favorites.value.toMutableSet()
        if (!next.add(id)) next.remove(id)
        _favorites.value = next
        prefs.edit().putString("favorite_live_ids", next.joinToString(",")).apply()
    }

    fun setDataSaver(on: Boolean) {
        _dataSaver.value = on
        prefs.edit().putBoolean("dataSaver", on).apply()
    }
}
