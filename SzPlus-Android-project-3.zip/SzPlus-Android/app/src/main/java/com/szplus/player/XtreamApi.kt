package com.szplus.player

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import kotlin.coroutines.cancellation.CancellationException

sealed class ApiError(message: String) : Exception(message) {
    object BadUrl : ApiError("bad url")
    object InvalidLogin : ApiError("invalid login")
    object Expired : ApiError("expired")
    object Unreachable : ApiError("unreachable")
    object Unexpected : ApiError("unexpected response")
}

const val USER_AGENT = "Mozilla/5.0 (Linux; Android 14) SzPlus/1.0"

class XtreamApi(context: Context, val creds: Credentials) {
    private val base: String
    private val cacheDir: File

    init {
        var s = creds.server.trim()
        if (!s.lowercase().startsWith("http")) s = "http://$s"
        while (s.endsWith("/")) s = s.dropLast(1)
        base = s

        val digest = MessageDigest.getInstance("SHA-256").digest("$s|${creds.username}".toByteArray())
        val folder = digest.take(8).joinToString("") { "%02x".format(it) }
        cacheDir = File(context.cacheDir, "api-$folder").also { it.mkdirs() }
    }

    companion object {
        private val client: OkHttpClient by lazy {
            OkHttpClient.Builder()
                .connectTimeout(20, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .callTimeout(180, TimeUnit.SECONDS)
                .followRedirects(true)
                .followSslRedirects(true)
                .build()
        }
    }

    // MARK: URLs

    private fun apiUrl(action: String?, extra: Map<String, String> = emptyMap()): String {
        val root = "$base/player_api.php".toHttpUrlOrNull() ?: throw ApiError.BadUrl
        val b = root.newBuilder()
            .addQueryParameter("username", creds.username)
            .addQueryParameter("password", creds.password)
        if (action != null) b.addQueryParameter("action", action)
        for ((k, v) in extra) b.addQueryParameter(k, v)
        return b.build().toString()
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    private fun cacheFile(action: String, extra: Map<String, String> = emptyMap()): File {
        val suffix = extra.toSortedMap().entries.joinToString("&") { "${it.key}=${it.value}" }
        return File(cacheDir, action + (if (suffix.isEmpty()) "" else "-$suffix") + ".json")
    }

    fun clearCache() {
        cacheDir.deleteRecursively()
    }

    // MARK: Networking (retries once on a bad connection)

    private suspend fun fetchText(action: String?, extra: Map<String, String> = emptyMap(), save: Boolean = false): String {
        val url = apiUrl(action, extra)
        var last: Throwable = ApiError.Unreachable
        for (attempt in 0 until 2) {
            try {
                val text = withContext(Dispatchers.IO) {
                    val req = Request.Builder().url(url).header("User-Agent", USER_AGENT).build()
                    client.newCall(req).execute().use { resp ->
                        if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
                        resp.body?.string() ?: throw IOException("empty body")
                    }
                }
                if (save && action != null) {
                    withContext(Dispatchers.IO) { runCatching { cacheFile(action, extra).writeText(text) } }
                }
                return text
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                last = e
                if (attempt == 0) delay(600)
            }
        }
        throw if (last is ApiError) last else ApiError.Unreachable
    }

    private suspend fun <T> parse(text: String, block: (String) -> T): T =
        withContext(Dispatchers.Default) {
            try {
                block(text)
            } catch (e: Exception) {
                throw ApiError.Unexpected
            }
        }

    private suspend fun <T> cached(action: String, block: (String) -> T): T? =
        withContext(Dispatchers.IO) {
            val f = cacheFile(action)
            if (!f.exists()) return@withContext null
            try {
                block(f.readText())
            } catch (e: Exception) {
                null
            }
        }

    // MARK: Auth

    suspend fun login() {
        val info = parse(fetchText(null), ::parseUserInfo)
        if (info == null || info.username == null) throw ApiError.InvalidLogin
        val status = info.status
        if (status != null && status.lowercase() != "active") throw ApiError.Expired
    }

    suspend fun accountInfo(): UserInfo =
        parse(fetchText(null), ::parseUserInfo) ?: throw ApiError.InvalidLogin

    /** TV guide: what is on now and next for a live channel. */
    suspend fun shortEpg(streamId: Int, limit: Int = 4): List<EpgEntry> =
        parse(
            fetchText("get_short_epg", mapOf("stream_id" to streamId.toString(), "limit" to limit.toString())),
            ::parseEpg,
        )

    // MARK: Live

    suspend fun liveCategories() = parse(fetchText("get_live_categories", save = true), ::parseCategories)
    suspend fun liveStreams() = parse(fetchText("get_live_streams", save = true), ::parseLive)
    suspend fun cachedLiveCategories() = cached("get_live_categories", ::parseCategories)
    suspend fun cachedLiveStreams() = cached("get_live_streams", ::parseLive)

    /** Candidate stream URLs, best first (HLS, then raw MPEG-TS). */
    fun liveUrls(s: LiveStream): List<String> =
        listOf("m3u8", "ts").map { "$base/live/${enc(creds.username)}/${enc(creds.password)}/${s.id}.$it" }

    // MARK: Movies

    suspend fun movieCategories() = parse(fetchText("get_vod_categories", save = true), ::parseCategories)
    suspend fun movies() = parse(fetchText("get_vod_streams", save = true), ::parseMovies)
    suspend fun cachedMovieCategories() = cached("get_vod_categories", ::parseCategories)
    suspend fun cachedMovies() = cached("get_vod_streams", ::parseMovies)
    fun movieUrl(m: Movie) = "$base/movie/${enc(creds.username)}/${enc(creds.password)}/${m.id}.${m.ext}"

    // MARK: Series

    suspend fun seriesCategories() = parse(fetchText("get_series_categories", save = true), ::parseCategories)
    suspend fun series() = parse(fetchText("get_series", save = true), ::parseSeries)
    suspend fun cachedSeriesCategories() = cached("get_series_categories", ::parseCategories)
    suspend fun cachedSeries() = cached("get_series", ::parseSeries)
    suspend fun seriesInfo(id: Int): Map<String, List<Episode>> =
        parse(fetchText("get_series_info", mapOf("series_id" to id.toString())), ::parseSeriesInfo)
    fun episodeUrl(e: Episode) = "$base/series/${enc(creds.username)}/${enc(creds.password)}/${e.id}.${e.ext}"
}
